// ============================================================
// 腕IKソルバー（二関節IK：上腕＋前腕）  ※純粋な数学モジュール
// ------------------------------------------------------------
// ・THREE.js・DOM・既存のFK処理には一切依存しない（数値だけで計算する）。
//   だから既存のFK／ポーズ／保存の処理と完全に分離されている。
// ・計算は「肩のボーンの親（characterGroup）のローカル座標」で行う。
//   キャラの横回転（characterRotateWrapper）はこの座標系の外側なので影響しない。
// ・出力は、既存のポーズデータと同じ角度表現（肩：rx/ry/rz、ひじ：rx）。
//   → IKで作った姿勢も、そのまま従来どおりの角度データとして保存できる。
//
// 既存モデルの腕の構造（character-body.js createArm）：
//   肩ボーン(root)から腕は「ローカル -Y 方向」へ伸びる。
//   ひじボーン(joint)は肩ボーンの子で、位置 (0, -L1, 0)。
//   手首(wrist)はひじボーンの子で、位置 (0, -L2, 0)。
//   肩の回転は Euler 'YXZ'（rx=前後 / ry=左右 / rz=ひねり）。
//   ひじは rx（前後）と rz のみを保存する（ry は保存されない）。
//
// ひじの扱い：
//   ひじは「ローカルX軸まわりの蝶番」として解く（曲げ角θ。前方=+Z側へ曲がる向き）。
//   θ<=90°：rx=-θ, rz=0。  θ>90°：肩を180°ひねり、rx=θ-π, rz=π（B案。保存形式を変えずに正確に保存するため）。
//   肩の回転（上腕のひねりを含む3自由度）で、ひじの曲がる面を
//   ポールターゲットの方向へ合わせる。
// ============================================================
(function (root) {
    'use strict';

    const DEFAULT_MAX_FLEX = 150 * Math.PI / 180; // ひじを曲げられる最大角（これ以上は届かない位置として制限）

    function clamp(v, lo, hi) { return v < lo ? lo : (v > hi ? hi : v); }
    function isNum(v) { return typeof v === 'number' && isFinite(v); }

    // 結果の入れ物（呼び出し側で1つ作って使い回すと、毎回のオブジェクト生成を避けられる）
    function createResult() {
        return {
            // 肩の角度（ラジアン、Euler YXZ）
            rx: 0, ry: 0, rz: 0,
            // ひじの角度（ラジアン）。蝶番なので rx のみ（<=0）、rz は常に 0
            elbowRx: 0, elbowRz: 0,
            // 実際に届く位置（ローカル座標）
            elbow: [0, 0, 0],
            wrist: [0, 0, 0],
            // 実際に採用した「ひじの向き」（肩→手首の線に垂直な単位ベクトル）
            poleDir: [0, 0, 1],
            clamped: false,   // 目標が届かず範囲内へ制限されたか
            reach: 0,         // 0=最も曲げた状態 〜 1=完全に伸びた状態
        };
    }

    // 肩→手首の線に垂直なポール方向を作る。作れなければ代替方向を試す。
    // 戻り値: true=成功（out の pole 成分へ書き込み）
    const _pole = [0, 0, 0];
    function makePerpPole(wx, wy, wz, px, py, pz) {
        // 候補を順に試す：与えられたポール → 後ろ(0,0,-1) → 横(1,0,0) → 上(0,1,0)
        const cands = [px, py, pz, 0, 0, -1, 1, 0, 0, 0, 1, 0];
        for (let i = 0; i < cands.length; i += 3) {
            const cx = cands[i], cy = cands[i + 1], cz = cands[i + 2];
            if (!isNum(cx) || !isNum(cy) || !isNum(cz)) continue;
            const dp = cx * wx + cy * wy + cz * wz;
            const qx = cx - dp * wx, qy = cy - dp * wy, qz = cz - dp * wz;
            const ql = Math.sqrt(qx * qx + qy * qy + qz * qz);
            if (ql > 1e-4) {
                _pole[0] = qx / ql; _pole[1] = qy / ql; _pole[2] = qz / ql;
                return true;
            }
        }
        return false;
    }

    // 二関節IKを解く。
    //   (sx,sy,sz) : 肩の位置        (tx,ty,tz) : 手首の目標位置
    //   (px,py,pz) : ひじの曲がる方向のヒント（単位でなくてもよい。肩→手首の線に垂直な成分だけ使う）
    //   L1, L2     : 上腕・前腕の長さ（実際のボーンの長さ）
    //   maxFlex    : ひじの最大屈曲（ラジアン、省略時150°）
    //   out        : createResult() の戻り値
    // 戻り値: true=解けた / false=入力が不正で何も書き込まなかった（NaN等は out に入らない）
    function solve(sx, sy, sz, tx, ty, tz, px, py, pz, L1, L2, maxFlex, out) {
        if (!out) return false;
        if (!isNum(sx) || !isNum(sy) || !isNum(sz) ||
            !isNum(tx) || !isNum(ty) || !isNum(tz)) return false;
        if (!isNum(L1) || !isNum(L2) || L1 <= 1e-6 || L2 <= 1e-6) return false;
        if (!isNum(maxFlex)) maxFlex = DEFAULT_MAX_FLEX;
        maxFlex = clamp(maxFlex, 10 * Math.PI / 180, 175 * Math.PI / 180);

        const dx = tx - sx, dy = ty - sy, dz = tz - sz;
        const dist = Math.sqrt(dx * dx + dy * dy + dz * dz);

        // 届く範囲：最大＝完全に伸ばした長さ／最小＝ひじを maxFlex まで曲げた時の距離
        const dMax = L1 + L2;
        const gammaMin = Math.PI - maxFlex; // ひじの内角の最小値
        const dMin = Math.sqrt(Math.max(0, L1 * L1 + L2 * L2 - 2 * L1 * L2 * Math.cos(gammaMin)));

        // 肩→手首の方向 w（目標が肩とほぼ同じ位置なら真下を使う）
        let wx, wy, wz;
        if (dist > 1e-6) { wx = dx / dist; wy = dy / dist; wz = dz / dist; }
        else { wx = 0; wy = -1; wz = 0; }

        const d = clamp(dist, dMin, dMax);
        const clamped = Math.abs(d - dist) > 1e-6;

        if (!makePerpPole(wx, wy, wz, px, py, pz)) return false;
        const hx = _pole[0], hy = _pole[1], hz = _pole[2];

        // 余弦定理：肩の位置での「肩→手首」と「肩→ひじ」の角度 α
        const cosA = clamp((L1 * L1 + d * d - L2 * L2) / (2 * L1 * d), -1, 1);
        const sinA = Math.sqrt(Math.max(0, 1 - cosA * cosA));

        // 上腕の向き u（ひじは手首の線からポール方向へ張り出す）
        const ux = wx * cosA + hx * sinA;
        const uy = wy * cosA + hy * sinA;
        const uz = wz * cosA + hz * sinA;

        const ex = sx + L1 * ux, ey = sy + L1 * uy, ez = sz + L1 * uz;       // ひじ
        const wrx = sx + d * wx, wry = sy + d * wy, wrz = sz + d * wz;       // 手首（到達位置）

        // 前腕の向き f と、ひじの曲げ角 θ
        const fx = (wrx - ex) / L2, fy = (wry - ey) / L2, fz = (wrz - ez) / L2;
        const theta = Math.acos(clamp(ux * fx + uy * fy + uz * fz, -1, 1));

        // 上腕ローカル座標系：Y = -u（腕は-Y方向へ伸びる）、Z = 曲げ面内で u に垂直（ひじの出っ張りの逆側）、X = Y×Z
        const Yx = -ux, Yy = -uy, Yz = -uz;
        const Zx = wx * sinA - hx * cosA;
        const Zy = wy * sinA - hy * cosA;
        const Zz = wz * sinA - hz * cosA;
        const Xx = Yy * Zz - Yz * Zy;
        const Xy = Yz * Zx - Yx * Zz;
        const Xz = Yx * Zy - Yy * Zx;

        // 回転行列（列 = X,Y,Z）から Euler 'YXZ' を取り出す（three.js の setFromRotationMatrix と同じ式）
        // ひじ90°超の場合（B案）：既存の保存形式はひじのry(Y成分)を保存しないため、
        // 純粋な蝶番 Rx(-θ) は深く曲げると保存→復元で前腕の向きが狂う。
        //   肩を上腕の軸まわりに180°ひねり（R * Ry(π)：列 X,Z の符号反転）、
        //   ひじを (rx = θ-π, ry = 0, rz = π) とすると、上腕の向き・前腕の姿勢（手の向き）は
        //   蝶番と全く同じで、ひじは「rx,rzのみ」で正確に保存できる。
        // 90°付近は Euler(YXZ) の特異点（ジンバル）。three.jsは |m23|>=0.9999999 でry/rzの分解を切り替えるため、
        // 切り替え点を「ちょうどその境界（90°+約0.0256°）」に置く。
        //   手前（蝶番のまま）：特異点側の分解となり、ry=0・誤差は0.05°未満（手首位置で約0.0007以下）
        //   向こう（肩180°ひねり）：通常側の分解となり、ry=0で正確に保存できる
        const flip = theta > Math.PI / 2 + 4.4721e-4;
        const sg = flip ? -1 : 1;
        const m11 = sg * Xx, m21 = sg * Xy, m31 = sg * Xz;
        const m13 = sg * Zx, m23 = sg * Zy, m33 = sg * Zz;
        let rx, ry, rz;
        rx = Math.asin(-clamp(m23, -1, 1));
        if (Math.abs(m23) < 0.9999999) {
            ry = Math.atan2(m13, m33);
            rz = Math.atan2(m21, Yy); // m22 = Y.y
        } else {
            ry = Math.atan2(-m31, m11);
            rz = 0;
        }
        if (!isNum(rx) || !isNum(ry) || !isNum(rz) || !isNum(theta)) return false;

        out.rx = rx; out.ry = ry; out.rz = rz;
        if (flip) { out.elbowRx = theta - Math.PI; out.elbowRz = Math.PI; }
        else { out.elbowRx = -theta; out.elbowRz = 0; }
        out.elbow[0] = ex; out.elbow[1] = ey; out.elbow[2] = ez;
        out.wrist[0] = wrx; out.wrist[1] = wry; out.wrist[2] = wrz;
        out.poleDir[0] = hx; out.poleDir[1] = hy; out.poleDir[2] = hz;
        out.clamped = clamped;
        out.reach = dMax > dMin ? clamp((d - dMin) / (dMax - dMin), 0, 1) : 1;
        return true;
    }

    const api = { solve: solve, createResult: createResult, DEFAULT_MAX_FLEX: DEFAULT_MAX_FLEX };
    if (typeof module !== 'undefined' && module.exports) module.exports = api; // Nodeでのテスト用
    root.ArmIKSolver = api;
})(typeof window !== 'undefined' ? window : globalThis);
