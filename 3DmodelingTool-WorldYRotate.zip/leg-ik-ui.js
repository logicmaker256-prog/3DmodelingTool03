// ============================================================
// 右足IK：操作ハンドル・IKモード内の「右足」選択（leg-ik-solver.js を使う画面側）
// ------------------------------------------------------------
// 約束（既存機能を壊さないために）:
//   ・初期状態は右足IKは無効。IKモードで「🦵 右足」を選ばない限り、このファイルは何もしない。
//   ・腕IK（arm-ik-ui.js）のFK/IK切り替え・「右腕／左腕」選択をそのまま使う。腕IKの計算は一切触らない。
//     連携は window.__ikLegActive（右足を選択中か）と、arm-ik-ui.js 側の小さなフックだけ。
//   ・動かすのは右脚（animatedParts.legs[1]）の「股関節」と「膝」だけ。
//     左脚・両腕・首・キャラ全体の位置/回転・カメラには触れない。足首の角度（足裏）も触らない。
//   ・結果は FK と同じ角度テーブル（pose-edit-gizmo.js の deg）へ書き、同じ経路でボーンへ反映する。
//     → ポーズ保存・ポーズ保管庫・GLB出力は FK で作った姿勢と同じ扱い。
//     （股関節の ry は任意項目として保存する。無いデータは 0 扱いなので、古いデータはそのまま読める）
//   ・ハンドルは scene 直下の専用 Group（GLB出力対象の characterGroup には入れない）。
//   ・選択を切り替えただけ・ハンドルをタップしただけでは姿勢を変えない（実際にドラッグした時だけ動く）。
// ============================================================
(function () {
    'use strict';
    if (window.__legIKUIInit) return;       // 二重初期化（イベントの二重登録）を防ぐ
    window.__legIKUIInit = true;
    window.__ikLegActive = false;

    const Solver = window.LegIKSolver;
    const btnLeg = document.getElementById('ik-leg-right');
    if (!Solver || !btnLeg || typeof THREE === 'undefined' ||
        typeof scene === 'undefined' || typeof camera === 'undefined' ||
        typeof renderer === 'undefined' || typeof controls === 'undefined') {
        console.warn('[legIK] 必要な部品が見つからないため、右足IKは無効です（他の機能は通常どおり使えます）');
        if (btnLeg) btnLeg.style.display = 'none';
        return;
    }

    const btnIK = document.getElementById('pose-mode-ik');
    const status = document.getElementById('pose-mode-status');
    const readout = document.getElementById('ik-readout');
    const noteEl = document.getElementById('ik-note');
    const tabPosing = document.getElementById('tab-posing');
    const btnArmR = document.getElementById('ik-arm-right');
    const btnArmL = document.getElementById('ik-arm-left');
    const dotTarget = document.getElementById('ik-dot-target');
    const dotPole = document.getElementById('ik-dot-pole');
    const legendTarget = document.getElementById('ik-legend-target');
    const legendPole = document.getElementById('ik-legend-pole');
    if (!btnIK || !tabPosing) { btnLeg.style.display = 'none'; return; }

    const LEG = 1;                           // 右脚（animatedParts.legs[1]、x<0）。FK画面の「👉 右」と同じ
    const MAX_FLEX = Solver.DEFAULT_MAX_FLEX;
    const POLE_OFFSET = 0.5;                 // 膝の向きハンドルを膝からどれだけ離して表示するか
    const TARGET_HIT_R = 0.36, POLE_HIT_R = 0.30;   // スマホの指でも掴める大きさ
    const REF_DIST = 10.4;
    const RAD2DEG = 180 / Math.PI;
    const COL_T = 0x43a047, BG_T = '#2e7d32', COL_P = 0xfdd835, BG_P = '#f9a825';

    let drag = null;
    const result = Solver.createResult();
    const lastPole = new THREE.Vector3(0, 0, 1);       // 直近の膝の向き（characterGroupローカル）。初期は前方
    const dragPoleLocal = new THREE.Vector3();
    const H = new THREE.Vector3(), K = new THREE.Vector3(), A = new THREE.Vector3();
    const _a = new THREE.Vector3(), _b = new THREE.Vector3(), _c = new THREE.Vector3(), _q = new THREE.Quaternion();
    const _wT = new THREE.Vector3(), _wK = new THREE.Vector3(), _wP = new THREE.Vector3();
    const _hit = new THREE.Vector3(), _dir = new THREE.Vector3(), _ndc = new THREE.Vector2();
    const raycaster = new THREE.Raycaster();
    const info = { leg: null, L1: 0, L2: 0 };

    function isIK() { return btnIK.classList.contains('active'); }

    // ── 脚の構造チェック（想定と違えばIKを使わない＝安全側） ──
    function getLegInfo() {
        if (typeof animatedParts === 'undefined' || !animatedParts || !animatedParts.legs) return null;
        if (typeof characterGroup === 'undefined' || !characterGroup) return null;
        const leg = animatedParts.legs[LEG];
        if (!leg || !leg.root || !leg.joint || !leg.ankle) return null;
        const root = leg.root, knee = leg.joint, ankle = leg.ankle;
        const sc = o => Math.abs(o.scale.x - 1) + Math.abs(o.scale.y - 1) + Math.abs(o.scale.z - 1);
        if (root.parent !== characterGroup || knee.parent !== root || ankle.parent !== knee) return null;
        if (sc(root) > 1e-5 || sc(knee) > 1e-5) return null;
        const j = knee.position, w = ankle.position;
        if (Math.abs(j.x) > 1e-4 || Math.abs(j.z) > 1e-4 || !(j.y < -1e-3)) return null;
        if (Math.abs(w.x) > 1e-4 || Math.abs(w.z) > 1e-4 || !(w.y < -1e-3)) return null;
        info.leg = leg; info.L1 = -j.y; info.L2 = -w.y;
        return info;
    }
    // 現在の股関節・膝・足首の位置（characterGroupローカル）をボーンの回転から求める
    function computeCurrent(inf) {
        const leg = inf.leg;
        H.copy(leg.root.position);
        _a.set(0, -inf.L1, 0).applyQuaternion(leg.root.quaternion);
        K.copy(H).add(_a);
        _q.copy(leg.root.quaternion).multiply(leg.joint.quaternion);
        _a.set(0, -inf.L2, 0).applyQuaternion(_q);
        A.copy(K).add(_a);
    }

    // ── ハンドル（scene直下。キャラ本体・GLB出力には入れない） ──
    const legRoot = new THREE.Group();
    legRoot.name = 'legIKHandles';
    legRoot.visible = false;
    legRoot.userData.excludeFromExport = true;
    scene.add(legRoot);

    function overlayMat(color, opacity) {
        return new THREE.MeshBasicMaterial({ color: color, transparent: true, opacity: opacity, depthTest: false, depthWrite: false });
    }
    function makeLabel(text, bg) {
        const cv = document.createElement('canvas');
        cv.width = 128; cv.height = 56;
        const ctx = cv.getContext('2d');
        ctx.fillStyle = bg;
        ctx.beginPath();
        if (ctx.roundRect) ctx.roundRect(4, 4, 120, 48, 14); else ctx.rect(4, 4, 120, 48);
        ctx.fill();
        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold ' + (text.length > 3 ? 22 : 30) + 'px sans-serif';
        ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillText(text, 64, 30);
        const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: new THREE.CanvasTexture(cv), transparent: true, depthTest: false, depthWrite: false }));
        sp.scale.set(0.56, 0.245, 1);
        sp.position.set(0, 0.36, 0);
        sp.renderOrder = 1003;
        return sp;
    }
    function makeHandle(color, bg, text, coreR, hitR, kind) {
        const g = new THREE.Group();
        g.userData.excludeFromExport = true;
        const core = new THREE.Mesh(new THREE.SphereGeometry(coreR, 18, 14), overlayMat(color, 0.9));
        core.renderOrder = 1001;
        const halo = new THREE.Mesh(new THREE.SphereGeometry(coreR * 1.7, 18, 14), overlayMat(color, 0.25));
        halo.renderOrder = 1000;
        const hit = new THREE.Mesh(new THREE.SphereGeometry(hitR, 8, 6), new THREE.MeshBasicMaterial({ visible: false }));
        hit.userData.legIkKind = kind;
        g.add(halo); g.add(core); g.add(hit); g.add(makeLabel(text, bg));
        legRoot.add(g);
        return { group: g, hit: hit };
    }
    const targetH = makeHandle(COL_T, BG_T, '右足首', 0.16, TARGET_HIT_R, 'target');
    const poleH = makeHandle(COL_P, BG_P, '右膝の向き', 0.12, POLE_HIT_R, 'pole');
    const hitList = [targetH.hit, poleH.hit];
    const lineGeo = new THREE.BufferGeometry();
    const linePos = new Float32Array(6);
    lineGeo.setAttribute('position', new THREE.BufferAttribute(linePos, 3));
    const poleLine = new THREE.Line(lineGeo, new THREE.LineBasicMaterial({ color: COL_P, transparent: true, opacity: 0.85, depthTest: false, depthWrite: false }));
    poleLine.frustumCulled = false;
    poleLine.renderOrder = 999;
    poleLine.userData.excludeFromExport = true;
    legRoot.add(poleLine);

    function screenScale(p) { return Math.min(4, Math.max(0.35, camera.position.distanceTo(p) / REF_DIST)); }
    function setNote(msg) { if (noteEl) noteEl.textContent = msg || ''; }
    function freezePose() {
        if (typeof idleEnabled !== 'undefined' && idleEnabled) {
            idleEnabled = false;
            if (typeof syncIdleSelect === 'function') syncIdleSelect(false);
        }
        if (typeof poseT !== 'undefined') poseT = 1.0;
    }

    // ── 表示：右足を選んでいる間だけ、腕IKのボタン・凡例・状態表示を右足用に上書きする ──
    // （arm-ik-ui.js の updateUI の最後から呼ばれる。右足が未選択なら右足ボタンを消灯するだけ）
    window._ikLegRefreshUI = function () {
        const on = !!window.__ikLegActive;
        btnLeg.classList.toggle('active', on);
        btnLeg.setAttribute('aria-pressed', on ? 'true' : 'false');
        if (!on) return;
        [btnArmR, btnArmL].forEach(function (b) {
            if (!b) return;
            b.classList.remove('active');
            b.setAttribute('aria-pressed', 'false');
        });
        if (status) status.textContent = '現在：IKモード（位置指定・右足）';
        if (dotTarget) dotTarget.style.background = '#43a047';
        if (dotPole) dotPole.style.background = '#fdd835';
        if (legendTarget) legendTarget.textContent = '緑の球＝右足首の目標（ドラッグで右脚が追従）';
        if (legendPole) legendPole.textContent = '黄色の球＝膝の向き（ドラッグで膝の曲がる方向を調整）';
    };

    function selectLeg() {
        if (!isIK() || drag || window.__ikLegActive) return;
        if (!getLegInfo()) { setNote('右足IKを使えません（脚の構造が想定と異なります）。'); return; }
        computeCurrent(info);
        initPoleFromPose();
        window.__ikLegLeftActive = false;                // 左足の選択は解除（同時に選ぶのは1つだけ。leg-ik-left-ui.js）
        window.__ikLegActive = true;                     // 姿勢は変えない。表示するハンドルが切り替わるだけ
        lastReadout = '';
        setNote('');
        if (typeof window._ikArmRefreshUI === 'function') window._ikArmRefreshUI(); else window._ikLegRefreshUI();
    }
    btnLeg.addEventListener('click', selectLeg);

    // 実際の膝の張り出し方向を lastPole に記憶（ほぼ真っすぐな脚では前回の向きを保つ。初期は前方）
    function initPoleFromPose() {
        _a.copy(A).sub(H);
        const wl = _a.length();
        if (wl <= 1e-6) return;
        _a.multiplyScalar(1 / wl);
        _b.copy(K).sub(H);
        _b.addScaledVector(_a, -_b.dot(_a));
        if (_b.length() > 0.03) lastPole.copy(_b).normalize();
    }

    // ── ドラッグ（腕IKと同じ作法：ハンドルに当たった時だけ処理し、それ以外はカメラ操作へ渡す） ──
    const container = renderer.domElement.parentElement || renderer.domElement;
    const canvas = renderer.domElement;
    function toNDC(cx, cy) {
        const r = canvas.getBoundingClientRect();
        return _ndc.set(((cx - r.left) / r.width) * 2 - 1, -((cy - r.top) / r.height) * 2 + 1);
    }
    function pointOf(e) {
        if (e.touches && e.touches.length) return e.touches[0];
        if (e.changedTouches && e.changedTouches.length) return e.changedTouches[0];
        return e;
    }
    function hitTest(e) {
        if (!window.__ikLegActive || !isIK() || !legRoot.visible || drag) return null;
        if (typeof seqFrames !== 'undefined' && seqFrames) return null;   // 動画編集の再生中は操作しない
        if (e.touches && e.touches.length > 1) return null;               // 2本指はカメラ操作に任せる
        if (e.type === 'mousedown' && e.button !== 0) return null;
        const pt = pointOf(e);
        raycaster.setFromCamera(toNDC(pt.clientX, pt.clientY), camera);
        const hits = raycaster.intersectObjects(hitList, false);
        return hits.length ? hits[0].object.userData.legIkKind : null;
    }
    function onPointerDownCapture(e) { if (hitTest(e)) e.stopPropagation(); }
    function onDown(e) {
        const kind = hitTest(e);
        if (!kind) return;
        const handle = kind === 'target' ? targetH.group : poleH.group;
        const pt = pointOf(e);
        raycaster.setFromCamera(toNDC(pt.clientX, pt.clientY), camera);
        camera.getWorldDirection(_dir);
        const plane = new THREE.Plane().setFromNormalAndCoplanarPoint(_dir, handle.position);   // 画面と平行な面
        if (!raycaster.ray.intersectPlane(plane, _hit)) return;
        drag = { kind: kind, plane: plane, moved: false, offset: new THREE.Vector3().copy(handle.position).sub(_hit) };
        controls.enabled = false;
        setNote('');
        e.preventDefault();
        e.stopPropagation();
    }
    function onMove(e) {
        if (!drag) return;
        if (e.cancelable) e.preventDefault();
        const pt = pointOf(e);
        raycaster.setFromCamera(toNDC(pt.clientX, pt.clientY), camera);
        if (!raycaster.ray.intersectPlane(drag.plane, _hit)) return;
        _hit.add(drag.offset);
        if (typeof characterGroup === 'undefined' || !characterGroup) return;
        characterGroup.updateWorldMatrix(true, false);
        characterGroup.worldToLocal(_hit);              // ワールド → characterGroupローカル（キャラの横回転を打ち消す）
        applyDrag(_hit);
    }
    function onUp() {
        if (!drag) return;
        const moved = drag.moved;
        drag = null;
        controls.enabled = true;
        if (moved && typeof autoSaveActiveSlot === 'function') autoSaveActiveSlot();   // FKと同じ：離した時に自動保存
    }
    function cancelDrag() {
        if (!drag) return;
        drag = null;
        controls.enabled = true;
    }
    container.addEventListener('pointerdown', onPointerDownCapture, true);
    container.addEventListener('mousedown', onDown, true);
    container.addEventListener('touchstart', onDown, { capture: true, passive: false });
    container.addEventListener('touchmove', onMove, { capture: true, passive: false });
    container.addEventListener('touchend', onUp, true);
    container.addEventListener('touchcancel', onUp, true);
    window.addEventListener('mousemove', onMove);
    window.addEventListener('mouseup', onUp);

    // ── IKの計算と角度テーブルへの反映 ──
    function applyDrag(localPt) {
        const inf = getLegInfo();
        if (!inf) { cancelDrag(); return; }
        if (!isFinite(localPt.x) || !isFinite(localPt.y) || !isFinite(localPt.z)) return;
        if (!drag.moved) { drag.moved = true; freezePose(); }   // 実際に動かした時だけ（タップでは姿勢を変えない）
        computeCurrent(inf);
        let ok;
        if (drag.kind === 'target') {
            // 足首の目標位置へ。膝の向きは直前の向きを引き継ぐ（連続的に変化し、反転しない）
            ok = Solver.solve(H.x, H.y, H.z, localPt.x, localPt.y, localPt.z,
                              lastPole.x, lastPole.y, lastPole.z, inf.L1, inf.L2, MAX_FLEX, result);
        } else {
            // 膝の向きだけを変える。足首は今の位置のまま
            dragPoleLocal.copy(localPt);
            _a.copy(localPt).sub(H);
            ok = Solver.solve(H.x, H.y, H.z, A.x, A.y, A.z, _a.x, _a.y, _a.z, inf.L1, inf.L2, MAX_FLEX, result);
        }
        if (!ok) return;                                 // 入力が不正（NaN等）なら何も変えない
        const set = window._poseEditSetJointDeg;
        if (typeof set !== 'function') return;
        // FKと同じ角度テーブルへ。書き込むのは右脚の股関節と膝だけ（膝は前後のみ）
        set('leg', LEG, 'hip', result.rx * RAD2DEG, result.ry * RAD2DEG, result.rz * RAD2DEG);
        set('leg', LEG, 'knee', result.kneeRx * RAD2DEG, 0, 0);
        lastPole.set(result.poleDir[0], result.poleDir[1], result.poleDir[2]);
        if (drag.kind === 'target') setNote(result.clamped ? '届く範囲の限界です（脚の長さは変わりません）' : '');
    }

    // ── 毎フレーム：ハンドルを実際の足首・膝の位置に合わせる（右足IK選択中のみ） ──
    let lastReadout = '';
    function legTick() {
        const inf = (window.__ikLegActive && isIK() && tabPosing.classList.contains('active')) ? getLegInfo() : null;
        if (!inf) {
            if (legRoot.visible) legRoot.visible = false;
            if (drag) cancelDrag();
            return;
        }
        legRoot.visible = true;
        computeCurrent(inf);
        _a.copy(A).sub(H);
        const wl = _a.length();
        if (wl > 1e-6) _a.multiplyScalar(1 / wl);
        if (!drag && wl > 1e-6) {                        // 実際の膝の張り出し方向を記憶
            _b.copy(K).sub(H);
            _b.addScaledVector(_a, -_b.dot(_a));
            if (_b.length() > 0.03) lastPole.copy(_b).normalize();
        }
        if (drag && drag.kind === 'pole') {
            _c.copy(dragPoleLocal);
        } else {
            _c.copy(lastPole);
            _c.addScaledVector(_a, -_c.dot(_a));
            if (_c.lengthSq() < 1e-8) _c.copy(lastPole);
            _c.normalize().multiplyScalar(POLE_OFFSET).add(K);
        }
        characterGroup.updateWorldMatrix(true, false);
        _wT.copy(A); characterGroup.localToWorld(_wT);
        _wK.copy(K); characterGroup.localToWorld(_wK);
        _wP.copy(_c); characterGroup.localToWorld(_wP);
        targetH.group.position.copy(_wT);
        targetH.group.scale.setScalar(screenScale(_wT));
        poleH.group.position.copy(_wP);
        poleH.group.scale.setScalar(screenScale(_wP));
        linePos[0] = _wK.x; linePos[1] = _wK.y; linePos[2] = _wK.z;
        linePos[3] = _wP.x; linePos[4] = _wP.y; linePos[5] = _wP.z;
        lineGeo.attributes.position.needsUpdate = true;

        // 数値表示（値が変わった時だけDOMを更新）
        const full = inf.L1 + inf.L2;
        const cosG = Math.max(-1, Math.min(1, (inf.L1 * inf.L1 + inf.L2 * inf.L2 - wl * wl) / (2 * inf.L1 * inf.L2)));
        const bend = Math.round(180 - Math.acos(cosG) * RAD2DEG);
        const reach = Math.round(Math.min(1, wl / full) * 100);
        const key = bend + '/' + reach;
        if (readout && key !== lastReadout) {
            lastReadout = key;
            readout.textContent = '右足　ひざの曲がり：' + bend + '°　脚ののび：' + reach + '%';
        }
    }
    // 既存の毎フレーム処理（腕IK）の後ろに連結する（腕IKの関数そのものは変更しない）
    const prevTick = window._ikArmTick;
    window._ikArmTick = function () {
        if (typeof prevTick === 'function') prevTick();
        legTick();
    };
})();
