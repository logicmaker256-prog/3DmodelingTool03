// ============================================================
// ポーズ全体の向き回転（ワールドY軸基準・プレビュー専用）
// ------------------------------------------------------------
// 目的: ポーズ全体の「正面」を、ワールド座標に対して変えて確認・編集できるようにする。
//       例）弓を引くポーズで、キャラの標準正面ではなく左肩方向から見た向きを正面として扱う。
//
// 【Group階層（回転の責任を持つGroupは characterRotateWrapper ただ1つ）】
//   scene
//    ├ axisHelperWorld        … ワールド固定のXYZ座標軸。回転対象ではない（親はscene直下）
//    ├ characterRotateWrapper … ★ここだけが回転する。rotation.y（＝ワールドY軸まわり）のみ使う
//    │   ├ characterGroup     … キャラ本体・全ボーン・小道具・衣服・髪・付属物（常に無回転・原点固定）
//    │   └ axisHelperFront    … ポーズ正面の目印（キャラと一緒に回る。ワールド座標軸とは別の親）
//    ├ FKギズモ / IKハンドル  … scene直下（ワールド座標で配置。毎フレーム最新のmatrixWorldから位置を求める）
//    └ camera / controls      … 回転しない
//
// 【ワールドY軸で回る理由】
//   characterRotateWrapper は scene の直接の子で、position=(0,0,0)・scale=1・x/z回転=0 に保つ。
//   このとき wrapper.rotation.y の回転軸 ＝ ワールドのY軸（鉛直軸）で、キャラのローカルY軸ではない。
//   characterGroup 自体には回転を一切かけない（二重回転の防止）。
//   毎フレーム applyAngle() が上の条件（親・位置・スケール・x/z回転）を確認し、外れていれば戻す。
//
// 【角度の一元管理】
//   向きの数値は、このファイルの angleDeg（度）だけが持つ。Groupの rotation.y は
//   常に angleDeg から導く（逆に rotation.y を読んで計算しない）。
//   アニメーション中は angleDeg を毎フレーム更新するので、停止・追加回転・正面復帰は
//   「いま見えている角度」からそのまま続く。角度は度で保持するため、1°×回数も誤差なく積算できる。
//
// 【既存機能を壊さないための約束】
//   ・ポーズデータ（関節角度）・セーブデータ・ボーン・animatedParts には一切触れない。
//   ・GLB出力は characterGroup を直接書き出す（親のラッパーは含まれない）ため、この回転は出力に混入しない。
//     ＝GLBは常に「回転0°（キャラ標準正面＝+Z）」の向きで出力される。
//   ・カメラ（OrbitControls）は動かさない。キャンバス上のドラッグ（カメラ・FK/IK操作）とも干渉しない。
//   ・アニメーションは専用のタイマー/rAFを持たず、animate()から毎フレーム呼ばれる
//     window._charRotateTick() だけで進む。キャラ再生成・画面切替で古い処理が残らない。
//   ・ボタンは onclick 代入で結び付ける（再初期化しても二重に反応しない）。
//   ・向きの定義：「右」＝正面が画面右（ワールド+X側）へ向く＝angleDeg が増える方向、
//     「左」＝減る方向。角度0°＝正面がワールド+Z。正面ベクトル＝(sinθ, 0, cosθ)。
// ============================================================
(function () {
    'use strict';
    if (typeof characterRotateWrapper === 'undefined' || typeof scene === 'undefined') return;
    const wrapper = characterRotateWrapper;

    const DEG = Math.PI / 180;
    const SPIN_SECONDS = 3.0;        // 360°回転にかける時間
    const STEP_SECONDS_PER_90 = 0.45; // 90°あたりの所要時間（小さい角度は比例して短く）
    const STEP_SECONDS_MIN = 0.08;

    // ★向きの唯一の管理値（度）。アニメーション中は連続値、静止時は (-180, 180] に正規化済み。
    let angleDeg = 0;
    // 現在進行中のアニメーション（同時に1つだけ）。無い時は null。
    // { kind:'step'|'spin'|'reset', from, to, rest, t0, dur }（角度はすべて度）
    let anim = null;

    // 角度を (-180, 180] に正規化する（数値が無制限に増えないようにする）
    function normalize(d) {
        d = d % 360;
        if (d > 180) d -= 360;
        else if (d <= -180) d += 360;
        return d;
    }
    function easeInOut(t) {
        return -(Math.cos(Math.PI * t) - 1) / 2; // 緩やかに加速・減速（ピーク速度が小さく、急に飛ばない）
    }

    // ── ワールドY軸回転の適用（回転の唯一の書き込み口） ─────────────────
    // wrapper が scene 直下・原点・等倍・x/z回転なし であることを毎回保証してから、rotation.y だけ書く。
    function applyAngle() {
        if (wrapper.parent !== scene) scene.add(wrapper);   // 親が外れていたら scene 直下へ戻す（二重親・取り残しの防止）
        wrapper.position.set(0, 0, 0);
        wrapper.scale.set(1, 1, 1);
        wrapper.rotation.set(0, angleDeg * DEG, 0);          // ワールドY軸まわりだけ
    }
    // 外部コードが勝手に wrapper の姿勢を変えていないか（管理角度とのずれ）
    function isDrifted() {
        const r = wrapper.rotation;
        return wrapper.parent !== scene ||
            Math.abs(r.y - angleDeg * DEG) > 1e-9 || Math.abs(r.x) > 1e-12 || Math.abs(r.z) > 1e-12 ||
            wrapper.position.lengthSq() > 1e-18 ||
            Math.abs(wrapper.scale.x - 1) > 1e-12 || Math.abs(wrapper.scale.y - 1) > 1e-12 || Math.abs(wrapper.scale.z - 1) > 1e-12;
    }

    function refreshButtons() {
        const spinBtn = document.getElementById('rot-spin');
        const stopBtn = document.getElementById('rot-stop');
        if (spinBtn) spinBtn.classList.toggle('active', !!anim && anim.kind === 'spin');
        if (stopBtn) stopBtn.disabled = !anim;
    }

    // ── 数値表示（回転メニュー内）：実際のオブジェクトの向きから計算して表示する ─────────
    //   管理角度ではなく characterGroup / 正面目印の matrixWorld から正面ベクトルを測るので、
    //   「見た目の向き」と「管理角度」がずれたら不一致として赤く表示される。
    const _fwd = new THREE.Vector3();
    function measureFrontDeg(obj) {
        if (!obj) return null;
        obj.updateWorldMatrix(true, false);
        _fwd.set(0, 0, 1).transformDirection(obj.matrixWorld);
        return { deg: Math.atan2(_fwd.x, _fwd.z) / DEG, x: _fwd.x, z: _fwd.z };
    }
    function angDiff(a, b) { return Math.abs(normalize(a - b)); }
    let lastReadout = '';
    function updateReadout() {
        const el = document.getElementById('rot-readout');
        if (!el) return;
        const cg = (typeof characterGroup !== 'undefined') ? characterGroup : null;
        const m = measureFrontDeg(cg);
        if (!m) return;
        const d = Math.round(m.deg * 10) / 10;
        const side = Math.abs(d) < 0.05 ? '回転なし（ワールド+Zと一致）' : (d > 0 ? ('右 ' + d.toFixed(1) + '°') : ('左 ' + (-d).toFixed(1) + '°'));
        const fm = (window.axisHelper && window.axisHelper._groups) ? measureFrontDeg(window.axisHelper._groups.front) : null;
        const ok = angDiff(m.deg, angleDeg) < 0.01 && (!fm || angDiff(fm.deg, m.deg) < 0.01);
        const txt = 'ポーズ正面：' + side + '\n正面ベクトル X ' + m.x.toFixed(2) + ' / Z ' + m.z.toFixed(2) +
            '（ワールド+Z ＝ X 0.00 / Z 1.00）' + (ok ? '' : '\n⚠ 管理角度と見た目の向きが不一致');
        if (txt === lastReadout) return;
        lastReadout = txt;
        el.textContent = txt;
        el.classList.toggle('mismatch', !ok);
    }

    // 進行中のアニメーションを確実に止め、「いま見えている角度」で固定する
    function stopAnim() {
        if (!anim) return;
        anim = null;
        angleDeg = normalize(angleDeg);   // 向きは変えず、数値だけ正規化する
        applyAngle();
        refreshButtons();
        updateReadout();
    }

    function startTween(kind, from, to, seconds, rest) {
        anim = { kind, from, to, rest, t0: performance.now(), dur: Math.max(0.01, seconds) };
        refreshButtons();
    }

    // 相対回転（度）。進行中のステップ回転の最中に押した場合は、その目標角度を基準に
    // 足し込む（素早く2回押せば確実に180°になる）。360°回転/正面復帰の最中だった場合は、
    // その時点の見た目の角度を基準にする。
    function rotateBy(deg) {
        const base = (anim && anim.kind === 'step') ? anim.to : angleDeg;
        const from = angleDeg;
        anim = null;
        const to = base + deg;
        const seconds = Math.max(STEP_SECONDS_MIN, STEP_SECONDS_PER_90 * Math.abs(to - from) / 90);
        startTween('step', from, to, seconds, normalize(to));
    }

    // 正面（ワールド+Z＝角度0）へ戻す。向きだけを戻し、ポーズには触れない。
    function resetFront() {
        stopAnim();
        const from = normalize(angleDeg);
        angleDeg = from;
        if (Math.abs(from) < 1e-9) { angleDeg = 0; applyAngle(); refreshButtons(); updateReadout(); return; }
        const seconds = 0.15 + 0.45 * Math.abs(from) / 180;
        startTween('reset', from, 0, seconds, 0);
    }

    // 360°回転（ワールドY軸まわりに一周）。回転中にもう一度呼ぶと停止する。
    function toggleSpin() {
        if (anim && anim.kind === 'spin') { stopAnim(); return; }
        stopAnim();
        const from = angleDeg;
        startTween('spin', from, from + 360, SPIN_SECONDS, normalize(from));
    }

    // animate()から毎フレーム呼ばれる。専用のタイマーは持たない。
    window._charRotateTick = function () {
        if (anim) {
            const t = Math.min(1, (performance.now() - anim.t0) / (anim.dur * 1000));
            if (t >= 1) {
                // 終了時は目標の向きにぴたりと合わせる（誤差を残さない）
                angleDeg = anim.rest;
                anim = null;
                refreshButtons();
            } else {
                angleDeg = anim.from + (anim.to - anim.from) * easeInOut(t);
            }
            applyAngle();
        } else if (isDrifted()) {
            applyAngle();   // 外部要因でラッパーの姿勢が管理角度からずれていたら、管理角度へ戻す
        }
        // 数値表示は回転メニューが開いている時だけ更新する（閉じている間は計算しない）
        const bar = document.getElementById('char-rotate-bar');
        if (bar && !bar.classList.contains('collapsed')) updateReadout();
    };

    // ── 自己診断（親子関係・座標軸の固定・向きの一致を実測する。コンソールやテストから呼べる） ──
    const _q = new THREE.Quaternion(), _p = new THREE.Vector3(), _s = new THREE.Vector3();
    function isDescendant(node, ancestor) {
        for (let n = node; n; n = n.parent) if (n === ancestor) return true;
        return false;
    }
    function diagnose() {
        const cg = (typeof characterGroup !== 'undefined') ? characterGroup : null;
        const grp = (window.axisHelper && window.axisHelper._groups) || {};
        const checks = {};
        scene.updateMatrixWorld(true);
        checks.wrapperParentIsScene = wrapper.parent === scene;
        checks.wrapperAtOriginUnitScale = wrapper.position.lengthSq() < 1e-18 && Math.abs(wrapper.scale.x - 1) < 1e-12 && Math.abs(wrapper.scale.y - 1) < 1e-12 && Math.abs(wrapper.scale.z - 1) < 1e-12;
        checks.wrapperOnlyYRotation = Math.abs(wrapper.rotation.x) < 1e-12 && Math.abs(wrapper.rotation.z) < 1e-12;
        checks.characterGroupInsideWrapper = !!cg && cg.parent === wrapper;
        checks.characterGroupNotRotatedItself = !!cg && Math.abs(cg.rotation.x) + Math.abs(cg.rotation.y) + Math.abs(cg.rotation.z) < 1e-12 && cg.position.lengthSq() < 1e-18;
        if (grp.world) {
            grp.world.matrixWorld.decompose(_p, _q, _s);
            checks.worldAxisParentIsScene = grp.world.parent === scene;
            checks.worldAxisNotRotated = Math.abs(_q.x) + Math.abs(_q.y) + Math.abs(_q.z) < 1e-9 && _q.w > 0;
            checks.worldAxisNotUnderWrapper = !isDescendant(grp.world, wrapper);
        }
        if (grp.front) {
            checks.frontMarkerInsideWrapper = isDescendant(grp.front, wrapper);
            checks.frontMarkerNotInsideCharacterGroup = !cg || !isDescendant(grp.front, cg);
        }
        const mc = measureFrontDeg(cg);
        const mf = measureFrontDeg(grp.front);
        checks.characterFrontMatchesAngle = !!mc && angDiff(mc.deg, angleDeg) < 0.01;
        checks.frontMarkerMatchesCharacter = !!mc && !!mf && angDiff(mf.deg, mc.deg) < 0.01;
        const ok = Object.keys(checks).every(function (k) { return checks[k]; });
        return { ok: ok, angleDeg: angleDeg, characterFrontDeg: mc && mc.deg, frontMarkerDeg: mf && mf.deg, checks: checks };
    }

    window.characterRotate = {
        rotateBy, resetFront, toggleSpin, stop: stopAnim,
        getAngleDeg: function () { return angleDeg; },
        isAnimating: function () { return !!anim; },
        diagnose
    };

    // onclick代入（再初期化しても二重に反応しない）
    function bind(id, fn) {
        const el = document.getElementById(id);
        if (el) el.onclick = fn;
    }
    bind('rot-left-90',  () => rotateBy(-90));
    bind('rot-left-1',   () => rotateBy(-1));
    bind('rot-right-1',  () => rotateBy(1));
    bind('rot-right-90', () => rotateBy(90));
    bind('rot-front',    resetFront);
    bind('rot-spin',     toggleSpin);
    bind('rot-stop',     stopAnim);
    // 回転メニューの折りたたみ（開閉しても回転状態・アニメーションには影響しない）
    bind('rot-toggle', () => {
        const bar = document.getElementById('char-rotate-bar');
        const toggle = document.getElementById('rot-toggle');
        if (!bar || !toggle) return;
        const collapsed = bar.classList.toggle('collapsed');
        toggle.textContent = collapsed ? '🔄 回転 ▲' : '🔄 回転 ▼';
        if (!collapsed) updateReadout();
    });
    applyAngle();
    refreshButtons();
})();
