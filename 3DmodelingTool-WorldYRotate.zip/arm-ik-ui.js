// ============================================================
// 腕IK（右腕・左腕）：操作ハンドル・FK/IKモード切り替え（arm-ik-solver.js を使う画面側）
// ------------------------------------------------------------
// 約束（既存機能を壊さないために）:
//   ・初期状態は必ずFKモード。IKモードに切り替えない限り、このファイルは何もしない
//     （毎フレームの処理もFKモード中は即return）。
//   ・IK操作の結果は、既存のFKと同じ「関節角度テーブル（pose-edit-gizmo.js の deg）」へ
//     書き込み、同じ経路（setBoneAnglesAsQuaternion）でボーンへ反映する。
//     → ポーズ保存・ポーズ保管庫・GLB出力は、FKで作った姿勢と全く同じ扱いになる。
//     → セーブデータ・ポーズデータの形式は一切変えていない。
//   ・動かすのは、選択中の腕（右=animatedParts.arms[1] / 左=animatedParts.arms[0]）の
//     「肩」と「ひじ」だけ。手首の角度・反対側の腕・脚・首・キャラ全体の位置/回転・カメラには触れない。
//   ・右腕と左腕は、状態（ひじの向きの記憶・ハンドル・腕の構造情報）を別々に持つ。
//     左右とも同じソルバー（arm-ik-solver.js）を使う。左右の腕は createArm() で同じ構造・同じ
//     ローカル軸で作られている（違いは肩のX位置だけ）ため、符号の反転などは不要。
//   ・IKモード内で「右腕／左腕」を選ぶ。操作できるのは選んだ腕のハンドルだけ。
//     選んでいない側の手首は、小さな半透明の点で位置だけ表示する（操作はできない）。
//   ・ハンドルは scene 直下の専用Group（GLB出力対象の characterGroup には入れない）。
//   ・FKギズモとは同時に有効にならない（IKモード中はFKギズモを隠し、FKのドラッグ処理も止める）。
//   ・タッチ/マウスの開始イベントは、ハンドルに当たった時だけ処理する。
//     それ以外はカメラ操作（OrbitControls）にそのまま渡す。
// ============================================================
(function () {
    'use strict';
    if (window.__armIKUIInit) return;      // 二重初期化（イベントの二重登録）を防ぐ
    window.__armIKUIInit = true;

    const Solver = window.ArmIKSolver;
    if (!Solver || typeof THREE === 'undefined' ||
        typeof scene === 'undefined' || typeof camera === 'undefined' ||
        typeof renderer === 'undefined' || typeof controls === 'undefined') {
        console.warn('[armIK] 必要な部品が見つからないため、IKモードは無効です（FKモードは通常どおり使えます）');
        return;
    }

    const btnFK   = document.getElementById('pose-mode-fk');
    const btnIK   = document.getElementById('pose-mode-ik');
    const status  = document.getElementById('pose-mode-status');
    const ikPanel = document.getElementById('ik-panel');
    const fkWrap  = document.getElementById('fk-controls');
    const readout = document.getElementById('ik-readout');
    const noteEl  = document.getElementById('ik-note');
    const tabPosing = document.getElementById('tab-posing');
    // 腕の選択ボタン・凡例（無くてもIK自体は動く。その場合は右腕のみ）
    const btnArmR = document.getElementById('ik-arm-right');
    const btnArmL = document.getElementById('ik-arm-left');
    const dotTarget = document.getElementById('ik-dot-target');
    const dotPole   = document.getElementById('ik-dot-pole');
    const legendTarget = document.getElementById('ik-legend-target');
    const legendPole   = document.getElementById('ik-legend-pole');
    if (!btnFK || !btnIK || !status || !ikPanel || !fkWrap || !tabPosing) {
        console.warn('[armIK] メニューの部品が見つからないため、IKモードは無効です');
        return;
    }

    // ── 定数 ─────────────────────────────────────────────
    const RIGHT = 1;                    // 右腕（animatedParts.arms[1]）。既存FK画面の「👉 右」と同じ
    const LEFT  = 0;                    // 左腕（animatedParts.arms[0]）。既存FK画面の「👈 左」と同じ
    const MAX_FLEX = Solver.DEFAULT_MAX_FLEX;
    const POLE_OFFSET = 0.5;             // 肘の向きハンドルを、肘からどれだけ離して表示するか
    const TARGET_HIT_R = 0.36;           // 当たり判定（スマホの指でも掴めるよう大きめ）
    const POLE_HIT_R = 0.30;
    const REF_DIST = 10.4;               // 初期カメラ距離。ハンドルの見た目の大きさを一定に保つ基準
    const RAD2DEG = 180 / Math.PI;

    let mode = 'fk';                     // 'fk' | 'ik'（初期は必ずFK）
    let activeArm = RIGHT;               // IKで操作中の腕（初期は右腕＝従来どおり）
    let drag = null;                     // ドラッグ中の情報（無ければ null）
    let lastNoteKey = '';

    // ── 作業用オブジェクト（毎フレーム生成しないよう使い回す） ──
    const result = Solver.createResult();
    const dragPoleLocal = new THREE.Vector3();
    const S = new THREE.Vector3(), E = new THREE.Vector3(), W = new THREE.Vector3();
    const _a = new THREE.Vector3(), _b = new THREE.Vector3(), _c = new THREE.Vector3();
    const _q = new THREE.Quaternion();
    const _wT = new THREE.Vector3(), _wE = new THREE.Vector3(), _wP = new THREE.Vector3();
    const _mS = new THREE.Vector3(), _mE = new THREE.Vector3(), _mW = new THREE.Vector3();
    const _hit = new THREE.Vector3(), _dir = new THREE.Vector3();
    const raycaster = new THREE.Raycaster();

    // ── 腕の構造チェック（想定と違えばIKを使わない＝安全側） ──
    function nearlyIdentity(o) {
        return !!o &&
            Math.abs(o.position.x) + Math.abs(o.position.y) + Math.abs(o.position.z) < 1e-5 &&
            Math.abs(o.quaternion.w) > 0.99999 &&
            Math.abs(o.scale.x - 1) + Math.abs(o.scale.y - 1) + Math.abs(o.scale.z - 1) < 1e-5;
    }
    // idx の腕（RIGHT/LEFT）の情報を返す。想定外の構造なら null。
    // 結果の入れ物は腕ごとに別（sides[idx].info）なので、左右で混ざらない。
    function getArmInfo(idx) {
        if (typeof animatedParts === 'undefined' || !animatedParts || !animatedParts.arms) return null;
        if (typeof characterGroup === 'undefined' || !characterGroup) return null;
        const side = sides[idx];
        if (!side) return null;
        const arm = animatedParts.arms[idx];
        if (!arm || !arm.root || !arm.joint || !arm.wrist) return null;
        const root = arm.root, joint = arm.joint, wrist = arm.wrist;
        if (root.parent !== characterGroup) return null;
        if (Math.abs(root.scale.x - 1) + Math.abs(root.scale.y - 1) + Math.abs(root.scale.z - 1) > 1e-5) return null;
        const upper = joint.parent, fore = wrist.parent;
        if (!upper || upper.parent !== root || !nearlyIdentity(upper)) return null;
        if (!fore || fore.parent !== joint || !nearlyIdentity(fore)) return null;
        const j = joint.position, w = wrist.position;
        if (Math.abs(j.x) > 1e-4 || Math.abs(j.z) > 1e-4 || !(j.y < -1e-3)) return null;
        if (Math.abs(w.x) > 1e-4 || Math.abs(w.z) > 1e-4 || !(w.y < -1e-3)) return null;
        const info = side.info;
        info.arm = arm; info.L1 = -j.y; info.L2 = -w.y;   // 実際のボーンの長さ
        return info;
    }

    // 現在の肩・ひじ・手首の位置（characterGroupローカル）を、ボーンの回転から求める
    // （出力先を省略すると共有の S/E/W へ。計算式は従来の右腕IKと同じ）
    function computeCurrent(inf, s, e, w) {
        s = s || S; e = e || E; w = w || W;
        const arm = inf.arm;
        s.copy(arm.root.position);
        _a.set(0, -inf.L1, 0).applyQuaternion(arm.root.quaternion);
        e.copy(s).add(_a);
        _q.copy(arm.root.quaternion).multiply(arm.joint.quaternion);
        _a.set(0, -inf.L2, 0).applyQuaternion(_q);
        w.copy(e).add(_a);
    }

    // ── ハンドル（scene直下。キャラ本体・GLB出力には入れない） ──
    const ikRoot = new THREE.Group();
    ikRoot.name = 'armIKHandles';
    ikRoot.visible = false;
    ikRoot.userData.excludeFromExport = true;
    scene.add(ikRoot);

    function overlayMat(color, opacity) {
        return new THREE.MeshBasicMaterial({ color: color, transparent: true, opacity: opacity, depthTest: false, depthWrite: false });
    }
    function makeLabel(text, bg) {
        const cv = document.createElement('canvas');
        cv.width = 128; cv.height = 56;
        const ctx = cv.getContext('2d');
        ctx.fillStyle = bg;
        ctx.beginPath();
        if (ctx.roundRect) ctx.roundRect(4, 4, 120, 48, 14); else ctx.rect(4, 4, 120, 48);
        ctx.fill();
        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold ' + (text.length > 3 ? 22 : 30) + 'px sans-serif';   // 長い文字は小さくして枠に収める
        ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillText(text, 64, 30);
        const tex = new THREE.CanvasTexture(cv);
        const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, transparent: true, depthTest: false, depthWrite: false }));
        sp.scale.set(0.56, 0.245, 1);
        sp.position.set(0, 0.36, 0);
        sp.renderOrder = 1003;
        return sp;
    }
    function makeHandle(color, labelBg, labelText, coreR, hitR, kind) {
        const g = new THREE.Group();
        g.userData.excludeFromExport = true;
        const core = new THREE.Mesh(new THREE.SphereGeometry(coreR, 18, 14), overlayMat(color, 0.9));
        core.renderOrder = 1001;
        const halo = new THREE.Mesh(new THREE.SphereGeometry(coreR * 1.7, 18, 14), overlayMat(color, 0.25));
        halo.renderOrder = 1000;
        const hit = new THREE.Mesh(new THREE.SphereGeometry(hitR, 8, 6), new THREE.MeshBasicMaterial({ visible: false }));
        hit.userData.ikKind = kind;
        g.add(halo); g.add(core); g.add(hit); g.add(makeLabel(labelText, labelBg));
        ikRoot.add(g);
        return { group: g, hit: hit };
    }

    // 腕ごとの状態（ハンドル・ひじの向きの記憶・構造情報）を1つにまとめる。左右で共有する値は無い。
    function makeSide(idx, spec) {
        const targetH = makeHandle(spec.targetColor, spec.targetBg, spec.name + '手首', 0.16, TARGET_HIT_R, 'target');
        const poleH   = makeHandle(spec.poleColor,   spec.poleBg,   spec.name + '肘の向き', 0.12, POLE_HIT_R, 'pole');

        // ひじ → ひじの向きハンドル を結ぶ線
        const lineGeo = new THREE.BufferGeometry();
        const linePos = new Float32Array(6);
        lineGeo.setAttribute('position', new THREE.BufferAttribute(linePos, 3));
        const poleLine = new THREE.Line(lineGeo, new THREE.LineBasicMaterial({ color: spec.poleColor, transparent: true, opacity: 0.8, depthTest: false, depthWrite: false }));
        poleLine.frustumCulled = false;          // 頂点を毎フレーム更新するため、視錐台カリングの対象外にする
        poleLine.renderOrder = 999;
        poleLine.userData.excludeFromExport = true;
        ikRoot.add(poleLine);

        // 選んでいない側の手首の位置を示す小さな点（当たり判定なし＝操作できない）
        const marker = new THREE.Mesh(new THREE.SphereGeometry(0.1, 12, 10), overlayMat(spec.targetColor, 0.55));
        marker.renderOrder = 990;                // 選択中のハンドル（1000〜）より後ろに描く
        marker.userData.excludeFromExport = true;
        marker.visible = false;
        ikRoot.add(marker);

        return {
            idx: idx, name: spec.name,
            info: { arm: null, L1: 0, L2: 0 },
            lastPole: new THREE.Vector3(0, 0, -1),     // 直近の「ひじの向き」（characterGroupローカル）
            targetH: targetH, poleH: poleH,
            hitList: [targetH.hit, poleH.hit],
            poleLine: poleLine, lineGeo: lineGeo, linePos: linePos,
            marker: marker,
        };
    }
    const sides = {};
    sides[RIGHT] = makeSide(RIGHT, { name: '右', targetColor: 0x00b8d4, targetBg: '#00838f', poleColor: 0xffab00, poleBg: '#e65100' });
    sides[LEFT]  = makeSide(LEFT,  { name: '左', targetColor: 0x7e57c2, targetBg: '#4527a0', poleColor: 0xec407a, poleBg: '#ad1457' });

    function screenScale(worldPos) {
        const d = camera.position.distanceTo(worldPos);
        return Math.min(4, Math.max(0.35, d / REF_DIST));
    }

    // ── 状態表示 ──────────────────────────────────────
    function setNote(msg) { if (noteEl) noteEl.textContent = msg || ''; }
    function updateUI() {
        const ik = mode === 'ik';
        const side = sides[activeArm];
        btnFK.classList.toggle('active', !ik);
        btnIK.classList.toggle('active', ik);
        btnFK.setAttribute('aria-pressed', ik ? 'false' : 'true');
        btnIK.setAttribute('aria-pressed', ik ? 'true' : 'false');
        status.textContent = ik
            ? '現在：IKモード（位置指定・' + side.name + '腕）'
            : '現在：FKモード（角度指定）';
        status.classList.toggle('ik', ik);
        fkWrap.style.display = ik ? 'none' : '';
        ikPanel.style.display = ik ? 'block' : 'none';
        document.body.classList.toggle('arm-ik-active', ik);
        // 腕の選択ボタン
        if (btnArmR) {
            btnArmR.classList.toggle('active', activeArm === RIGHT);
            btnArmR.setAttribute('aria-pressed', activeArm === RIGHT ? 'true' : 'false');
        }
        if (btnArmL) {
            btnArmL.classList.toggle('active', activeArm === LEFT);
            btnArmL.setAttribute('aria-pressed', activeArm === LEFT ? 'true' : 'false');
        }
        // 凡例（選んだ腕の色・名前に合わせる）
        const tHex = activeArm === LEFT ? '#7e57c2' : '#00b8d4';
        const pHex = activeArm === LEFT ? '#ec407a' : '#ffab00';
        if (dotTarget) dotTarget.style.background = tHex;
        if (dotPole)   dotPole.style.background = pHex;
        if (legendTarget) legendTarget.textContent = (activeArm === LEFT ? '紫' : '水色') + 'の球＝' + side.name + '手首の目標（ドラッグで' + side.name + '腕が追従）';
        if (legendPole)   legendPole.textContent   = (activeArm === LEFT ? 'ピンク' : '橙色') + 'の球＝肘の向き（ドラッグで肘の曲がる方向を調整）';
        if (window._ikLegRefreshUI) window._ikLegRefreshUI();   // 右足IK（leg-ik-ui.js）の表示を重ねる。未選択なら右足ボタンを消灯するだけ
        if (window._ikLegLeftRefreshUI) window._ikLegLeftRefreshUI();   // 左足IK（leg-ik-left-ui.js）の表示を重ねる。未選択なら左足ボタンを消灯するだけ
    }
    window._ikArmRefreshUI = updateUI;

    // ── アイドル・ポーズ補間の停止（FKでギズモを動かし始めた時の stopIdle と同じ処理） ──
    // 腕の姿勢はその時点のまま固定される（姿勢が跳ねない）。
    function freezePose() {
        if (typeof idleEnabled !== 'undefined' && idleEnabled) {
            idleEnabled = false;
            if (typeof syncIdleSelect === 'function') syncIdleSelect(false);
        }
        if (typeof poseT !== 'undefined') poseT = 1.0;
    }

    // ── モード切り替え ──────────────────────────────────
    function setMode(next) {
        if (next === mode) return;
        if (next === 'ik') {
            if (typeof window._poseEditSetIKMode !== 'function' || typeof window._poseEditSetJointDeg !== 'function') {
                setNote('IKモードを開始できません（FK側の準備が見つかりません）。FKモードのままです。');
                return;
            }
            const infR = getArmInfo(RIGHT), infL = getArmInfo(LEFT);
            if (!infR && !infL) {
                setNote('このキャラでは腕IKを使えません（腕の構造が想定と異なります）。FKモードのままです。');
                return;
            }
            if (!getArmInfo(activeArm)) activeArm = infR ? RIGHT : LEFT;   // 選んでいた腕が使えない時だけ、使える方へ
            mode = 'ik';
            freezePose();                                    // 今の姿勢のまま固定（ここでは腕を一切動かさない）
            [RIGHT, LEFT].forEach(function (idx) {           // ひじの向きの初期値（曲がっていれば毎フレーム実際の向きに更新される）
                const inf = getArmInfo(idx);
                if (!inf) return;
                _a.set(0, 0, -1).applyQuaternion(inf.arm.root.quaternion);
                sides[idx].lastPole.copy(_a);
            });
            window._poseEditSetIKMode(true);                 // FKギズモ・FKスライダーを隠し、FKのドラッグ処理を止める
            setNote('');
        } else {
            cancelDrag();
            mode = 'fk';
            ikRoot.visible = false;
            if (typeof window._poseEditSetIKMode === 'function') window._poseEditSetIKMode(false);
            setNote('');
        }
        updateUI();
    }
    btnFK.addEventListener('click', function () { setMode('fk'); });
    btnIK.addEventListener('click', function () { setMode('ik'); });

    // 操作する腕の切り替え（姿勢は一切変えない。表示するハンドルが切り替わるだけ）
    function selectArm(idx) {
        if (mode !== 'ik' || drag) return;               // ドラッグ中は切り替えない
        if (window.__ikLegActive || window.__ikLegLeftActive) { window.__ikLegActive = false; window.__ikLegLeftActive = false; }   // 右足・左足IKから腕へ戻す（同じ腕でも表示を更新する）
        else if (idx === activeArm) return;
        if (!getArmInfo(idx)) {
            setNote('この腕ではIKを使えません（腕の構造が想定と異なります）。');
            return;
        }
        activeArm = idx;
        lastReadout = '';                                // 数値表示を作り直す
        setNote('');
        updateUI();
    }
    if (btnArmR) btnArmR.addEventListener('click', function () { selectArm(RIGHT); });
    if (btnArmL) btnArmL.addEventListener('click', function () { selectArm(LEFT); });

    // ── ドラッグ ─────────────────────────────────────
    const container = renderer.domElement.parentElement || renderer.domElement;
    const canvas = renderer.domElement;

    function toNDC(cx, cy, out) {
        const r = canvas.getBoundingClientRect();
        return out.set(((cx - r.left) / r.width) * 2 - 1, -((cy - r.top) / r.height) * 2 + 1);
    }
    const _ndc = new THREE.Vector2();
    function pointOf(e) {
        if (e.touches && e.touches.length) return e.touches[0];
        if (e.changedTouches && e.changedTouches.length) return e.changedTouches[0];
        return e;
    }
    function hitTest(e) {
        if (mode !== 'ik' || !ikRoot.visible || drag) return null;
        if (typeof seqFrames !== 'undefined' && seqFrames) return null;   // 動画編集の再生中は操作しない
        if (e.touches && e.touches.length > 1) return null;               // 2本指はカメラ操作に任せる
        if (e.type === 'mousedown' && e.button !== 0) return null;
        if (window.__ikLegActive || window.__ikLegLeftActive) return null;   // 右足・左足IKを選択中は腕のハンドルを操作しない（leg-ik-ui.js / leg-ik-left-ui.js）
        const pt = pointOf(e);
        raycaster.setFromCamera(toNDC(pt.clientX, pt.clientY, _ndc), camera);
        const hits = raycaster.intersectObjects(sides[activeArm].hitList, false);   // 当たるのは選んだ腕のハンドルだけ
        return hits.length ? hits[0].object.userData.ikKind : null;
    }

    function onPointerDownCapture(e) {
        // マウスでは pointerdown が先に OrbitControls へ届く。ハンドル上なら、ここで止めてカメラ回転を始めさせない。
        if (hitTest(e)) e.stopPropagation();
    }
    function onDown(e) {
        const kind = hitTest(e);
        if (!kind) return;                       // ハンドル以外＝カメラ操作へそのまま渡す
        const side = sides[activeArm];
        const handle = kind === 'target' ? side.targetH.group : side.poleH.group;
        const pt = pointOf(e);
        raycaster.setFromCamera(toNDC(pt.clientX, pt.clientY, _ndc), camera);
        camera.getWorldDirection(_dir);
        const plane = new THREE.Plane().setFromNormalAndCoplanarPoint(_dir, handle.position); // 画面と平行な面（ドラッグ開始時の1回だけ生成）
        if (!raycaster.ray.intersectPlane(plane, _hit)) return;
        drag = {
            arm: activeArm,                      // このドラッグが担当する腕（途中で選択が変わっても混ざらない）
            kind: kind, plane: plane, moved: false,
            offset: new THREE.Vector3().copy(handle.position).sub(_hit),   // 掴んだ位置とハンドル中心のずれ
        };
        controls.enabled = false;
        setNote('');
        e.preventDefault();
        e.stopPropagation();
    }
    function onMove(e) {
        if (!drag) return;
        if (e.cancelable) e.preventDefault();
        const pt = pointOf(e);
        raycaster.setFromCamera(toNDC(pt.clientX, pt.clientY, _ndc), camera);
        if (!raycaster.ray.intersectPlane(drag.plane, _hit)) return;
        _hit.add(drag.offset);
        if (typeof characterGroup === 'undefined' || !characterGroup) return;
        characterGroup.updateWorldMatrix(true, false);
        characterGroup.worldToLocal(_hit);                  // ワールド → characterGroupローカル（キャラの横回転の影響を打ち消す）
        applyDrag(_hit);
    }
    function onUp() {
        if (!drag) return;
        const moved = drag.moved;
        drag = null;
        controls.enabled = true;
        if (moved && typeof autoSaveActiveSlot === 'function') autoSaveActiveSlot();   // FKと同じ：離した時に自動保存
    }
    function cancelDrag() {
        if (!drag) return;
        drag = null;
        controls.enabled = true;
    }

    container.addEventListener('pointerdown', onPointerDownCapture, true);
    container.addEventListener('mousedown', onDown, true);
    container.addEventListener('touchstart', onDown, { capture: true, passive: false });
    container.addEventListener('touchmove', onMove, { capture: true, passive: false });
    container.addEventListener('touchend', onUp, true);
    container.addEventListener('touchcancel', onUp, true);
    window.addEventListener('mousemove', onMove);           // 画面外へはみ出してもドラッグを続けられる
    window.addEventListener('mouseup', onUp);

    // ── IKの計算と関節角度テーブルへの反映 ──────────────────
    function applyDrag(localPt) {
        const side = sides[drag.arm];
        const inf = getArmInfo(drag.arm);
        if (!inf) { cancelDrag(); return; }
        if (!isFinite(localPt.x) || !isFinite(localPt.y) || !isFinite(localPt.z)) return;
        if (!drag.moved) {                       // 実際に動かし始めた時だけ（タップだけでは姿勢を変えない）
            drag.moved = true;
            freezePose();
        }
        computeCurrent(inf);
        const lp = side.lastPole;
        let ok;
        if (drag.kind === 'target') {
            // 手首の目標位置へ。ひじの向きは「直前の向き」を引き継ぐ（連続的に変化し、反転しない）
            ok = Solver.solve(S.x, S.y, S.z, localPt.x, localPt.y, localPt.z,
                              lp.x, lp.y, lp.z, inf.L1, inf.L2, MAX_FLEX, result);
        } else {
            // ひじの向きだけを変える。手首は今の位置のまま
            dragPoleLocal.copy(localPt);
            _a.copy(localPt).sub(S);
            ok = Solver.solve(S.x, S.y, S.z, W.x, W.y, W.z,
                              _a.x, _a.y, _a.z, inf.L1, inf.L2, MAX_FLEX, result);
        }
        if (!ok) return;                         // 入力が不正（NaN等）なら何も変えない
        commit(result, side);
        if (drag.kind === 'target') setNote(result.clamped ? '届く範囲の限界です（腕の長さは変わりません）' : '');
    }
    function commit(res, side) {
        const set = window._poseEditSetJointDeg;
        if (typeof set !== 'function') return;
        // 既存のFKと同じ角度テーブルへ（肩：前後/左右/ひねり、ひじ：前後のみ）。書き込むのは side の腕だけ。
        set('arm', side.idx, 'shoulder', res.rx * RAD2DEG, res.ry * RAD2DEG, res.rz * RAD2DEG);
        set('arm', side.idx, 'elbow', res.elbowRx * RAD2DEG, 0, res.elbowRz * RAD2DEG);
        side.lastPole.set(res.poleDir[0], res.poleDir[1], res.poleDir[2]);
    }

    // ── 毎フレーム：ハンドルを実際の手首・ひじの位置に合わせる（IKモード中のみ） ──
    let lastReadout = '';
    window._ikArmTick = function () {
        if (mode !== 'ik') {
            if (ikRoot.visible) ikRoot.visible = false;
            return;
        }
        if (window.__ikLegActive || window.__ikLegLeftActive) {   // 右足・左足IKを選択中：腕のハンドルは出さない（脚側が処理する）
            if (ikRoot.visible) ikRoot.visible = false;
            if (drag) cancelDrag();
            return;
        }
        const side = sides[activeArm];
        const other = sides[activeArm === RIGHT ? LEFT : RIGHT];
        const inf = tabPosing.classList.contains('active') ? getArmInfo(activeArm) : null;
        if (!inf) {
            ikRoot.visible = false;
            if (drag) cancelDrag();
            return;
        }
        ikRoot.visible = true;
        // 選んだ腕のハンドルだけ表示。もう一方の腕のハンドルは隠す（点だけ、この関数の最後で出す）
        side.targetH.group.visible = true; side.poleH.group.visible = true; side.poleLine.visible = true; side.marker.visible = false;
        other.targetH.group.visible = false; other.poleH.group.visible = false; other.poleLine.visible = false;
        computeCurrent(inf);

        // 肩→手首の向き
        _a.copy(W).sub(S);
        const wl = _a.length();
        if (wl > 1e-6) _a.multiplyScalar(1 / wl);

        // 実際のひじの張り出し方向を、ひじの向きとして記憶（ほぼ真っすぐな腕では前回の向きを保つ）
        if (!drag && wl > 1e-6) {
            _b.copy(E).sub(S);
            _b.addScaledVector(_a, -_b.dot(_a));
            if (_b.length() > 0.03) side.lastPole.copy(_b).normalize();
        }

        // ひじの向きハンドルの位置
        if (drag && drag.kind === 'pole') {
            _c.copy(dragPoleLocal);
        } else {
            _c.copy(side.lastPole);
            _c.addScaledVector(_a, -_c.dot(_a));
            if (_c.lengthSq() < 1e-8) _c.copy(side.lastPole);
            _c.normalize().multiplyScalar(POLE_OFFSET).add(E);
        }

        characterGroup.updateWorldMatrix(true, false);
        _wT.copy(W); characterGroup.localToWorld(_wT);
        _wE.copy(E); characterGroup.localToWorld(_wE);
        _wP.copy(_c); characterGroup.localToWorld(_wP);

        side.targetH.group.position.copy(_wT);
        side.targetH.group.scale.setScalar(screenScale(_wT));
        side.poleH.group.position.copy(_wP);
        side.poleH.group.scale.setScalar(screenScale(_wP));

        const lp = side.linePos;
        lp[0] = _wE.x; lp[1] = _wE.y; lp[2] = _wE.z;
        lp[3] = _wP.x; lp[4] = _wP.y; lp[5] = _wP.z;
        side.lineGeo.attributes.position.needsUpdate = true;

        // 数値表示（値が変わった時だけDOMを更新）
        const full = inf.L1 + inf.L2;
        const cosG = Math.max(-1, Math.min(1, (inf.L1 * inf.L1 + inf.L2 * inf.L2 - wl * wl) / (2 * inf.L1 * inf.L2)));
        const bend = Math.round(180 - Math.acos(cosG) * RAD2DEG);
        const reach = Math.round(Math.min(1, wl / full) * 100);
        const key = activeArm + '/' + bend + '/' + reach;
        if (readout && key !== lastReadout) {
            lastReadout = key;
            readout.textContent = side.name + '腕　ひじの曲がり：' + bend + '°　腕ののび：' + reach + '%';
        }

        // 選んでいない側の腕：手首の位置に小さな点だけ表示（操作はできない。専用の作業用ベクトルを使う）
        const infO = getArmInfo(other.idx);
        if (infO) {
            computeCurrent(infO, _mS, _mE, _mW);
            _wT.copy(_mW); characterGroup.localToWorld(_wT);
            other.marker.position.copy(_wT);
            other.marker.scale.setScalar(screenScale(_wT));
            other.marker.visible = true;
        } else {
            other.marker.visible = false;
        }
    };

    updateUI();   // 初期表示：FKモード
})();
