// ============================================================
// ポーズ編集パネル（腕・脚 両対応）＋ドラッグ式ギズモ
// 腕: arms[0]=左, arms[1]=右 / root=肩甲骨, joint=ひじ, wrist=手首
// 脚: legs[0]=左, legs[1]=右 / root=股関節, joint=膝関節, ankle=足首
// ============================================================
(function () {
    // 選択中: 肢（'arm'|'leg'）, 左右（0=左,1=右）, パーツ
    let selLimb = 'arm';
    let selSide = 1;       // 初期=右
    let selPart = 'shoulder';

    // 角度テーブル（腕・脚それぞれ左右×パーツ、首は左右なし）
    const deg = {
        arm: {
            0: { shoulder:{x:0,y:0,z:0}, elbow:{x:0,y:0,z:0}, wrist:{x:0,y:0,z:0} },
            1: { shoulder:{x:0,y:0,z:0}, elbow:{x:0,y:0,z:0}, wrist:{x:0,y:0,z:0} },
        },
        leg: {
            0: { hip:{x:0,y:0,z:0}, knee:{x:0,y:0,z:0}, ankle:{x:0,y:0,z:0} },
            1: { hip:{x:0,y:0,z:0}, knee:{x:0,y:0,z:0}, ankle:{x:0,y:0,z:0} },
        },
        neck: {
            0: { neck:{x:0,y:0,z:0}, head:{x:0,y:0,z:0} },
        },
    };

    // パーツ名リスト（肢ごと）
    const PARTS = {
        arm:  ['shoulder','elbow','wrist'],
        leg:  ['hip','knee','ankle'],
        neck: ['neck','head'],
    };

    // 右上スライダーパネルのタイトル表示用（アイコン付きパーツ名）
    const PART_TITLE_LABELS = {
        shoulder:'🦴 肩甲骨', elbow:'💪 ひじ', wrist:'✋ 手首',
        hip:'🦴 股関節', knee:'🦵 膝関節', ankle:'🦶 足首',
        neck:'🦒 首', head:'👤 頭',
    };

    // ボーン取得
    function getBone(limb, side, part) {
        if (limb === 'neck') {
            if (part === 'neck') return animatedParts.neck || null;
            if (part === 'head') return animatedParts.head || null;
            return null;
        }
        if (limb === 'arm') {
            if (!animatedParts.arms || !animatedParts.arms[side]) return null;
            const a = animatedParts.arms[side];
            return part === 'shoulder' ? a.root
                 : part === 'elbow'    ? a.joint
                 : part === 'wrist'    ? a.wrist : null;
        } else {
            if (!animatedParts.legs || !animatedParts.legs[side]) return null;
            const l = animatedParts.legs[side];
            if (part === 'hip')   return l.root;
            if (part === 'knee')  return l.joint;
            if (part === 'ankle') {
                // ankle は knee の子Meshなので子から探す
                const knee = l.joint;
                if (!knee) return null;
                for (let i = 0; i < knee.children.length; i++) {
                    const c = knee.children[i];
                    if (c.isMesh && c.geometry &&
                        c.geometry.type === 'SphereGeometry') return c;
                }
                return null;
            }
        }
        return null;
    }

    // deg[limb][side][part] の x=前後(Pitch)/y=左右(Yaw)/z=ひねり(Roll) [度] を
    // Quaternionに合成してボーンへ適用する（bone.rotation.x/y/zの個別代入はしない）。
    function applyBone(limb, side, part) {
        const bone = getBone(limb, side, part);
        if (!bone) return;
        const d = deg[limb][side][part], r = Math.PI / 180;
        setBoneAnglesAsQuaternion(bone, d.x * r, d.y * r, d.z * r);
    }

    window._poseEditApplyAll = function () {
        ['arm','leg'].forEach(limb =>
            [0,1].forEach(side =>
                PARTS[limb].forEach(part => applyBone(limb, side, part))
            )
        );
        PARTS.neck.forEach(part => applyBone('neck', 0, part));
    };
    window._poseEditApplyAfterPose = function () {
        ['arm','leg'].forEach(limb =>
            [0,1].forEach(side =>
                PARTS[limb].forEach(part => applyBone(limb, side, part))
            )
        );
        PARTS.neck.forEach(part => applyBone('neck', 0, part));
    };

    // スナップショットの値をdegテーブルに同期する（保存ポーズ適用時に呼ぶ）
    // snapshotはsnapshotCurrentRotationsの形式: arms[i].root.rx など（ラジアン）
    window._poseEditSyncDeg = function (snapshot) {
        if (!snapshot) return;
        const R = 180 / Math.PI;
        // 腕
        (snapshot.arms || []).forEach((a, i) => {
            if (!deg.arm[i]) return;
            deg.arm[i].shoulder = { x: (a.root?.rx  ?? 0)*R, y: (a.root?.ry  ?? 0)*R, z: (a.root?.rz  ?? 0)*R };
            deg.arm[i].elbow    = { x: (a.joint?.rx ?? 0)*R, y: 0,                      z: (a.joint?.rz ?? 0)*R };
            deg.arm[i].wrist    = { x: (a.wrist?.rx ?? 0)*R, y: (a.wrist?.ry ?? 0)*R, z: (a.wrist?.rz ?? 0)*R };
        });
        // 脚
        (snapshot.legs || []).forEach((l, i) => {
            if (!deg.leg[i]) return;
            deg.leg[i].hip   = { x: (l.root?.rx  ?? 0)*R, y: (l.root?.ry ?? 0)*R, z: (l.root?.rz  ?? 0)*R };   // ryは任意項目（古いデータは0）
            deg.leg[i].knee  = { x: (l.joint?.rx ?? 0)*R, y: 0, z: 0 };
            deg.leg[i].ankle = { x: 0, y: 0, z: 0 };
        });
        syncInputs(); // 入力欄も更新
    };

    function syncInputs() {
        const side = selLimb === 'neck' ? 0 : selSide;
        const d = deg[selLimb][side][selPart];
        const rx = Math.round(d.x), ry = Math.round(d.y), rz = Math.round(d.z);
        document.getElementById('input-rx').value = rx;
        document.getElementById('input-ry').value = ry;
        document.getElementById('input-rz').value = rz;

        // ★キャラ表示画面・右上の独立スライダーパネルも同期する
        document.getElementById('slider-rx').value = rx;
        document.getElementById('slider-ry').value = ry;
        document.getElementById('slider-rz').value = rz;
        document.getElementById('slider-rx-val').textContent = rx + '°';
        document.getElementById('slider-ry-val').textContent = ry + '°';
        document.getElementById('slider-rz-val').textContent = rz + '°';

        const sideLabel = selLimb === 'neck' ? '' : (side === 1 ? '👉右 ' : '👈左 ');
        document.getElementById('joint-slider-title').textContent =
            sideLabel + PART_TITLE_LABELS[selPart];
    }

    // ── ギズモ構築 ─────────────────────────────────────────────
    const AXIS_DEF = [
        { key:'x', colorNormal:0xe53935, colorHL:0xff6d6d, rz:0,         ry:0          },
        { key:'y', colorNormal:0x43a047, colorHL:0x76ff7a, rz:Math.PI/2, ry:0          },
        { key:'z', colorNormal:0x1e88e5, colorHL:0x64b5f6, rz:0,         ry:-Math.PI/2 },
    ];
    const ARROW_LEN  = 0.55;
    const HEAD_LEN   = 0.13;
    const T_NORMAL   = 0.013;
    const T_HL       = 0.026;
    const HIT_RAD    = 0.18;

    function makeShaftPts(t) {
        return [
            0,0,0,  ARROW_LEN-HEAD_LEN,0,0,
            0,t,0,  ARROW_LEN-HEAD_LEN,t,0,
            0,-t,0, ARROW_LEN-HEAD_LEN,-t,0,
            0,0,t,  ARROW_LEN-HEAD_LEN,0,t,
            0,0,-t, ARROW_LEN-HEAD_LEN,0,-t,
        ];
    }

    function buildAxisGroup(axDef) {
        const g = new THREE.Group();
        g.renderOrder = 999;

        // 通常
        const ng = new THREE.Group(); ng.renderOrder = 999;
        const sgN = new THREE.BufferGeometry();
        sgN.setAttribute('position', new THREE.Float32BufferAttribute(makeShaftPts(T_NORMAL),3));
        const smN = new THREE.LineBasicMaterial({ color:axDef.colorNormal, depthTest:false, depthWrite:false, transparent:true, opacity:0.8 });
        const slN = new THREE.LineSegments(sgN, smN); slN.renderOrder=999; ng.add(slN);
        const hgN = new THREE.ConeGeometry(0.055, HEAD_LEN, 10);
        const hmN = new THREE.MeshBasicMaterial({ color:axDef.colorNormal, depthTest:false, depthWrite:false, transparent:true, opacity:0.8 });
        const hN  = new THREE.Mesh(hgN, hmN); hN.rotation.z=-Math.PI/2; hN.position.x=ARROW_LEN-HEAD_LEN/2; hN.renderOrder=999; ng.add(hN);
        g.add(ng);

        // ハイライト
        const hg = new THREE.Group(); hg.renderOrder=999; hg.visible=false;
        const sgH = new THREE.BufferGeometry();
        sgH.setAttribute('position', new THREE.Float32BufferAttribute(makeShaftPts(T_HL),3));
        const smH = new THREE.LineBasicMaterial({ color:axDef.colorHL, depthTest:false, depthWrite:false, transparent:true, opacity:1.0 });
        const slH = new THREE.LineSegments(sgH, smH); slH.renderOrder=999; hg.add(slH);
        const hgH = new THREE.ConeGeometry(0.075, HEAD_LEN*1.25, 10);
        const hmH = new THREE.MeshBasicMaterial({ color:axDef.colorHL, depthTest:false, depthWrite:false, transparent:true, opacity:1.0 });
        const hH  = new THREE.Mesh(hgH, hmH); hH.rotation.z=-Math.PI/2; hH.position.x=ARROW_LEN-HEAD_LEN*1.25/2; hH.renderOrder=999; hg.add(hH);
        g.add(hg);

        // hit球
        const hit = new THREE.Mesh(
            new THREE.SphereGeometry(HIT_RAD,8,8),
            new THREE.MeshBasicMaterial({ visible:false })
        );
        hit.position.x = ARROW_LEN;
        hit.userData.axisKey = axDef.key;
        g.add(hit);

        g.rotation.z = axDef.rz;
        g.rotation.y = axDef.ry;
        return { g, hlGroup:hg, hitMesh:hit };
    }

    const gizmoRoot = new THREE.Group();
    gizmoRoot.renderOrder=999; gizmoRoot.visible=false;
    scene.add(gizmoRoot);

    // ── 選択中の関節を「赤く」ハイライトする球 ──────────────────
    // 関節メッシュ自体の素材(skinMat)は全身のパーツで共有されているため、
    // 直接色を変えると全身が赤くなってしまう。代わりに選択中の関節の位置
    // （gizmoRootの原点＝ボーンの位置）に半透明の赤い球を重ねて表示し、
    // 「今どの関節を操作しているか」が一目でわかるようにする。
    const highlightMesh = new THREE.Mesh(
        new THREE.SphereGeometry(0.23, 20, 16),
        new THREE.MeshBasicMaterial({
            color: 0xff1744, transparent: true, opacity: 0.55,
            depthTest: false, depthWrite: false,
        })
    );
    highlightMesh.renderOrder = 998; // 矢印(999)より下、キャラより上
    gizmoRoot.add(highlightMesh);

    // ── XY移動 / XZ移動 のドラッグハンドル（平面ハンドル：四角いパネル） ──────────
    //   key 'x' = XY移動（赤）、key 'y' = XZ移動（緑）。key 'z'（ひねり）は従来どおりの矢印。
    //   内部のキー名(x/y/z)は変えない（deg・保存形式・他ファイルとの対応を保つため）。
    const PLANE_C = 0.34, PLANE_S = 0.24, PLANE_S_HL = 0.30;
    function buildPlaneHandle(axDef) {
        const isXY = axDef.key === 'x';
        const center = isXY ? [PLANE_C, PLANE_C, 0] : [PLANE_C, 0, PLANE_C];
        const g = new THREE.Group(); g.renderOrder = 999;
        function panel(size, color, fillOpacity, lineOpacity) {
            const grp = new THREE.Group(); grp.renderOrder = 999;
            const geo = new THREE.PlaneGeometry(size, size);
            if (!isXY) geo.rotateX(-Math.PI / 2);          // XZ平面に寝かせる（XY平面は既定のまま）
            const fill = new THREE.Mesh(geo, new THREE.MeshBasicMaterial({
                color, side: THREE.DoubleSide, transparent: true, opacity: fillOpacity,
                depthTest: false, depthWrite: false }));
            fill.renderOrder = 999; fill.position.set(center[0], center[1], center[2]); grp.add(fill);
            const edge = new THREE.LineSegments(new THREE.EdgesGeometry(geo), new THREE.LineBasicMaterial({
                color, transparent: true, opacity: lineOpacity, depthTest: false, depthWrite: false }));
            edge.renderOrder = 999; edge.position.set(center[0], center[1], center[2]); grp.add(edge);
            return grp;
        }
        g.add(panel(PLANE_S, axDef.colorNormal, 0.45, 0.95));
        const hg = panel(PLANE_S_HL, axDef.colorHL, 0.75, 1.0); hg.visible = false; g.add(hg);
        const hit = new THREE.Mesh(new THREE.SphereGeometry(0.17, 8, 8), new THREE.MeshBasicMaterial({ visible:false }));
        hit.position.set(center[0], center[1], center[2]);
        hit.userData.axisKey = axDef.key;
        g.add(hit);
        return { g, hlGroup: hg, hitMesh: hit };
    }

    const hitMeshes=[], hlGroups={};
    AXIS_DEF.forEach(axDef => {
        const { g, hlGroup, hitMesh } = (axDef.key === 'z') ? buildAxisGroup(axDef) : buildPlaneHandle(axDef);
        gizmoRoot.add(g);
        hitMeshes.push(hitMesh);
        hlGroups[axDef.key] = hlGroup;
    });

    function setHighlight(k)  { Object.keys(hlGroups).forEach(key => { hlGroups[key].visible=(key===k); }); }
    function clearHighlight() { Object.values(hlGroups).forEach(g=>{ g.visible=false; }); }

    const _wPos=new THREE.Vector3(), _wQuat=new THREE.Quaternion(), _wScl=new THREE.Vector3();

    window._poseEditGizmoUpdate = function () {
        if (!gizmoRoot.visible) return;
        const side = selLimb === 'neck' ? 0 : selSide;
        const bone = getBone(selLimb, side, selPart);
        if (!bone) return;
        bone.updateWorldMatrix(true, false);
        bone.matrixWorld.decompose(_wPos, _wQuat, _wScl);
        gizmoRoot.position.copy(_wPos);
        // ★軸の向きは関節の角度に追従させず、補助座標（axis-helper.js・scene直下でワールド固定）と同じ
        //   ワールド軸(+X/+Y/+Z)に固定する。位置だけが関節に追従する。補助座標の表示ON/OFFとは無関係。
        gizmoRoot.quaternion.identity();
    };

    // ── ドラッグ ──────────────────────────────────────────────
    const raycaster=new THREE.Raycaster(), canvas=renderer.domElement;
    let dragging=false, dragAxisKey=null, dragStartXY={x:0,y:0}, dragStartDeg=0;

    // ★ワールド軸ドラッグ用（補助座標と同じ軸まわりに回すための作業変数。毎フレーム確保しない）
    //   新しいローカル回転 = inv(親ワールド回転) * ワールド軸回転 * 親ワールド回転 * 開始時ローカル回転
    const WORLD_AXIS = { x:new THREE.Vector3(1,0,0), y:new THREE.Vector3(0,1,0), z:new THREE.Vector3(0,0,1) };
    let dragBone=null;
    const _dragQ0=new THREE.Quaternion(), _dragP=new THREE.Quaternion(), _dragPinv=new THREE.Quaternion();
    const _axisQ=new THREE.Quaternion(), _newQ=new THREE.Quaternion();
    let _dragE0={rx:0,ry:0,rz:0};
    const _dpPos=new THREE.Vector3(), _dpScl=new THREE.Vector3();

    // ── XY移動 / XZ移動：画面のドラッグを「骨の先端が動く方向」に変換し、既存のFK回転にする ──────────
    //   ・骨の長さ方向（腕・脚は -Y、首・頭は +Y）の向き d0 を、ドラッグ量ぶんの移動ベクトル m の方向へ
    //     最短回転（スイング）させる。骨そのものの位置・長さ・親子関係は変えない（回転だけ）。
    //   ・m は「XY平面」または「XZ平面」の中だけで作る（XY移動はZ成分0、XZ移動はY成分0）。
    //   ・平面の向きはワールド座標基準（補助座標と同じ）。左右/上下の符号だけカメラの向きに合わせる。
    const PLANE_GAIN = 2.5;   // 画面の短辺いっぱいドラッグしたときの移動ベクトルの長さ
    let dragPlane = null;     // null | 'xy' | 'xz'
    const _d0=new THREE.Vector3(), _planeH=new THREE.Vector3(), _planeV=new THREE.Vector3();
    const _planeN=new THREE.Vector3(), _planeRef=new THREE.Vector3();
    const _pm=new THREE.Vector3(), _pmh=new THREE.Vector3(), _pp=new THREE.Vector3(), _pq=new THREE.Vector3();
    const _swingQ=new THREE.Quaternion(), _tmpWQ=new THREE.Quaternion(), _camQ=new THREE.Quaternion();
    const _cR=new THREE.Vector3(), _cU=new THREE.Vector3(), _cF=new THREE.Vector3();
    const _tv1=new THREE.Vector3(), _tv2=new THREE.Vector3();
    const _cgQ=new THREE.Quaternion();   // characterGroup のワールド回転（ポーズ全体の向き回転を含む）

    // 移動ベクトル m（平面内）に対するスイング回転を _swingQ に求める（純粋な計算。テスト用に公開）
    function planeSwing(d0, m, planeN, ref, out) {
        const len = m.length();
        if (len < 1e-6) return out.identity();
        _pmh.copy(m).divideScalar(len);
        _pp.copy(d0).add(m);
        // 骨の向きと移動方向がほぼ正反対/同方向のとき（例：垂れた腕を真上へ）は、行き先が一意に決まらないので、
        // 平面内の「外側/正面側」へ少し逃がして、滑らかに回り込ませる
        const w = Math.max(0, Math.min(1, (Math.abs(d0.dot(_pmh)) - 0.7) / 0.3));
        if (w > 0) {
            _pq.crossVectors(planeN, _pmh);
            if (_pq.lengthSq() > 1e-8) {
                _pq.normalize();
                if (_pq.dot(ref) < 0) _pq.negate();
                _pp.addScaledVector(_pq, 0.3 * w * len);
            }
        }
        if (_pp.lengthSq() < 1e-8) return out.identity();
        return out.setFromUnitVectors(d0, _pp.normalize());
    }
    window._poseEditPlaneSwing = planeSwing;

    // ドラッグ開始時：平面内の「画面の右」「画面の上」に当たるワールドベクトルと、骨の向き d0 を求める
    function setupPlaneDrag(plane, bone) {
        camera.updateMatrixWorld(true);
        camera.getWorldQuaternion(_camQ);
        _cR.set(1,0,0).applyQuaternion(_camQ);
        _cU.set(0,1,0).applyQuaternion(_camQ);
        _cF.set(0,0,-1).applyQuaternion(_camQ);
        if (plane === 'xy') {
            _planeN.set(0,0,1);
            _planeH.set(_cR.x,_cR.y,0); _planeV.set(_cU.x,_cU.y,0);
        } else {
            _planeN.set(0,1,0);
            _planeH.set(_cR.x,0,_cR.z); _planeV.set(_cF.x+_cU.x,0,_cF.z+_cU.z);
        }
        if (_planeH.lengthSq() < 1e-6) _planeH.set(1,0,0);
        if (_planeV.lengthSq() < 1e-6) { if (plane === 'xy') _planeV.set(0,1,0); else _planeV.set(0,0,-1); }
        _planeH.normalize(); _planeV.normalize();
        // 骨の向き（ワールド）：骨のローカル -Y（首・頭は +Y）を、ドラッグ開始時の回転で向ける
        _tmpWQ.copy(_dragP).multiply(_dragQ0);
        _d0.set(0, selLimb === 'neck' ? 1 : -1, 0).applyQuaternion(_tmpWQ).normalize();
        // 逃がし方向の基準：XY移動＝キャラの外側（体の中心から見て関節がある側）、XZ移動＝キャラの正面側。
        //   ポーズ全体の向き回転（character-rotate.js）は characterGroup の「親」が回すため、キャラの向きは
        //   characterGroup.quaternion（常に単位）ではなく、ワールド回転(getWorldQuaternion)で求める。
        //   回転0°では従来と完全に同じ値になる。移動する平面そのもの（XY/XZ）は回転後もワールド基準のまま。
        const cg = (typeof characterGroup !== 'undefined' && characterGroup) ? characterGroup : null;
        if (cg) { cg.updateWorldMatrix(true, false); cg.getWorldQuaternion(_cgQ); } else { _cgQ.identity(); }
        if (plane === 'xy') {
            bone.getWorldPosition(_tv1);
            if (cg) cg.getWorldPosition(_tv2); else _tv2.set(0,0,0);
            const worldSign = (_tv1.x - _tv2.x) >= 0 ? 1 : -1;      // 従来の判定（ワールドXで見た左右）
            let outward = worldSign;
            if (cg) { _tv2.copy(_tv1); cg.worldToLocal(_tv2); outward = _tv2.x >= 0 ? 1 : -1; }   // キャラから見た左右
            _planeRef.set(outward, 0, 0).applyQuaternion(_cgQ);       // キャラの「外側」をワールド方向へ
            // XY平面の中に外側成分がほとんど残らない向き（キャラが横向き）では、従来のワールドX判定へ戻す
            if (Math.abs(_planeRef.x) + Math.abs(_planeRef.y) < 1e-3) _planeRef.set(worldSign, 0, 0);
        } else {
            _planeRef.set(0,0,1);
            if (cg) { _planeRef.applyQuaternion(_cgQ); _planeRef.y = 0; if (_planeRef.lengthSq() < 1e-6) _planeRef.set(0,0,1); _planeRef.normalize(); }
        }
    }

    function toNDC(cx,cy) {
        const r=canvas.getBoundingClientRect();
        return new THREE.Vector2(((cx-r.left)/r.width)*2-1, -((cy-r.top)/r.height)*2+1);
    }
    function stopIdle() {
        idleEnabled=false;
        syncIdleSelect(false);
        poseT=1.0;
    }

    function onPointerDown(e) {
        if (!gizmoRoot.visible) return;
        const pt=e.touches?e.touches[0]:e;
        raycaster.setFromCamera(toNDC(pt.clientX,pt.clientY),camera);
        const hits=raycaster.intersectObjects(hitMeshes);
        if (!hits.length) return;
        dragAxisKey=hits[0].object.userData.axisKey;
        dragStartXY={x:pt.clientX,y:pt.clientY};
        const side = selLimb === 'neck' ? 0 : selSide;
        dragStartDeg=deg[selLimb][side][selPart][dragAxisKey];
        dragBone=getBone(selLimb, side, selPart);
        if (dragBone) {
            _dragQ0.copy(dragBone.quaternion);
            _dragE0=quaternionToAngles(_dragQ0);   // 保存されない成分を維持するための開始時の角度
            if (dragBone.parent) {
                dragBone.parent.updateWorldMatrix(true, false);
                dragBone.parent.matrixWorld.decompose(_dpPos, _dragP, _dpScl);
            } else { _dragP.identity(); }
            _dragPinv.copy(_dragP).invert();
        }
        dragPlane = (dragAxisKey==='x') ? 'xy' : (dragAxisKey==='y') ? 'xz' : null;   // x=XY移動 / y=XZ移動 / z=ひねり
        if (dragBone && dragPlane) setupPlaneDrag(dragPlane, dragBone);
        dragging=true; controls.enabled=false;
        setHighlight(dragAxisKey);
        e.preventDefault(); e.stopPropagation();
    }
    function onPointerMove(e) {
        if (!dragging) return;
        const pt=e.touches?e.touches[0]:e;
        const r=canvas.getBoundingClientRect();
        const fullPx=Math.min(r.width,r.height);
        // ひねり(z)は従来どおり：縦ドラッグ量を角度[度]にする（XY移動/XZ移動は下で平面ベクトルにする）
        const delta=-(pt.clientY-dragStartXY.y)/fullPx*360;
        const side = selLimb === 'neck' ? 0 : selSide;
        if (dragBone) {
            // ワールド軸（補助座標の軸）まわりに delta 度回し、親のワールド回転でボーンのローカル回転へ変換する。
            if (dragPlane) {
                // XY移動/XZ移動：ドラッグ(右, 上)を平面内の移動ベクトルにして、骨の先端をそちらへスイングさせる
                const sx=(pt.clientX-dragStartXY.x)/fullPx*PLANE_GAIN, sy=-(pt.clientY-dragStartXY.y)/fullPx*PLANE_GAIN;
                _pm.copy(_planeH).multiplyScalar(sx).addScaledVector(_planeV, sy);
                planeSwing(_d0, _pm, _planeN, _planeRef, _axisQ);
            } else {
                const dd=Math.max(-180,Math.min(180,delta))*Math.PI/180;
                _axisQ.setFromAxisAngle(WORLD_AXIS[dragAxisKey], dd);
            }
            _newQ.copy(_dragPinv).multiply(_axisQ).multiply(_dragP).multiply(_dragQ0);
            const ang=quaternionToAngles(_newQ);
            // 保存形式に存在しない成分は、開始時の値のまま変えない（保存→読込で姿勢が変わらないようにする）
            //   ひじ: rx/rzのみ保存 → ryを維持 ／ 膝: rxのみ保存 → ry,rzを維持
            if (selLimb==='arm' && selPart==='elbow') { ang.ry=_dragE0.ry; }
            else if (selLimb==='leg' && selPart==='knee') { ang.ry=_dragE0.ry; ang.rz=_dragE0.rz; }
            const R=180/Math.PI, c=(t)=>Math.max(-180,Math.min(180,t));
            deg[selLimb][side][selPart]={ x:c(ang.rx*R), y:c(ang.ry*R), z:c(ang.rz*R) };
        } else if (!dragPlane) {
            const v=Math.max(-180,Math.min(180,dragStartDeg+delta));
            deg[selLimb][side][selPart][dragAxisKey]=v;
        }
        stopIdle(); applyBone(selLimb,side,selPart); syncInputs();
        e.preventDefault();
    }
    function onPointerUp() {
        if (!dragging) return;
        dragging=false; dragBone=null; dragPlane=null; controls.enabled=true; clearHighlight();
        autoSaveActiveSlot();
    }

    canvas.addEventListener('touchstart', onPointerDown, {passive:false});
    canvas.addEventListener('touchmove',  onPointerMove, {passive:false});
    canvas.addEventListener('touchend',   onPointerUp);
    canvas.addEventListener('mousedown',  onPointerDown);
    canvas.addEventListener('mousemove',  onPointerMove);
    canvas.addEventListener('mouseup',    onPointerUp);

    // ── UIパーツボタンの更新 ─────────────────────────────────
    function updatePartButtons() {
        const container = document.getElementById('part-buttons-container');
        container.innerHTML = '';
        // 首モードは左右タブを隠す
        const sideTabButtons = document.getElementById('side-tab-buttons');
        sideTabButtons.style.display = selLimb === 'neck' ? 'none' : '';

        PARTS[selLimb].forEach((part, i) => {
            const labels = {
                shoulder:'🦴 肩甲骨', elbow:'💪 ひじ', wrist:'✋ 手首',
                hip:'🦴 股関節', knee:'🦵 膝関節', ankle:'🦶 足首',
                neck:'🦒 首', head:'👤 頭',
            };
            const btn = document.createElement('button');
            btn.className = 'arm-part-btn' + (part===selPart?' active':'');
            btn.dataset.part = part;
            btn.textContent = labels[part];
            btn.addEventListener('click', () => {
                selPart = part;
                container.querySelectorAll('.arm-part-btn').forEach(b=>b.classList.remove('active'));
                btn.classList.add('active');
                syncInputs(); showGizmo(); clearHighlight();
            });
            container.appendChild(btn);
        });
    }

    // ★右腕IKモード中（arm-ik-ui.js）は、FKギズモ・右上スライダー・FKのドラッグ処理を止める。
    //   FKモード（初期状態）ではこのフラグは常に false で、従来と動作は同じ。
    let ikSuspended = false;

    function showGizmo() {
        if (ikSuspended) return;
        gizmoRoot.visible=true;
        const panel = document.getElementById('joint-slider-panel');
        if (panel) panel.style.display = 'block';
    }
    function hideGizmo() {
        gizmoRoot.visible=false;
        const panel = document.getElementById('joint-slider-panel');
        if (panel) panel.style.display = 'none';
    }

    // 肢タブ（腕/脚/首）
    document.querySelectorAll('.limb-tab-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            selLimb = btn.dataset.limb;
            // 切り替え時の初期パーツ
            if      (selLimb === 'arm')  selPart = 'shoulder';
            else if (selLimb === 'leg')  selPart = 'hip';
            else if (selLimb === 'neck') selPart = 'neck';
            document.querySelectorAll('.limb-tab-btn').forEach(b=>b.classList.remove('active'));
            btn.classList.add('active');
            updatePartButtons(); syncInputs(); showGizmo(); clearHighlight();
        });
    });

    // 左右タブ
    document.querySelectorAll('.side-tab-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            selSide=parseInt(btn.dataset.side);
            document.querySelectorAll('.side-tab-btn').forEach(b=>b.classList.remove('active'));
            btn.classList.add('active');
            syncInputs(); showGizmo(); clearHighlight();
        });
    });

    // 角度をまとめて反映するヘルパー（数値入力・右上スライダーの両方から呼ぶ）
    function setAngle(axis, v) {
        v = Math.max(-180, Math.min(180, v));
        const side = selLimb === 'neck' ? 0 : selSide;
        deg[selLimb][side][selPart][axis] = v;
        stopIdle();
        applyBone(selLimb, side, selPart);
        syncInputs();
    }

    // 角度入力（数値欄）
    [['input-rx','x'],['input-ry','y'],['input-rz','z']].forEach(([id,axis])=>{
        const el=document.getElementById(id);
        function onInput(){
            let v=parseFloat(el.value); if(isNaN(v)) return;
            setAngle(axis, v);
            autoSaveActiveSlot();
        }
        el.addEventListener('input', onInput);
        el.addEventListener('change', onInput);
    });

    // 角度スライダー（キャラ表示画面・右上の独立パネル）
    // -180°〜180°の範囲。ドラッグ中はリアルタイムにポーズへ反映し、
    // 指を離した瞬間（changeイベント）にだけ自動保存する。
    [['slider-rx','x'],['slider-ry','y'],['slider-rz','z']].forEach(([id,axis])=>{
        const el=document.getElementById(id);
        el.addEventListener('input', ()=>{
            let v=parseFloat(el.value); if(isNaN(v)) return;
            setAngle(axis, v);
        });
        el.addEventListener('change', ()=> autoSaveActiveSlot());
    });

    // リセット
    document.getElementById('arm-reset-btn').addEventListener('click',()=>{
        const side = selLimb === 'neck' ? 0 : selSide;
        deg[selLimb][side][selPart]={x:0,y:0,z:0};
        syncInputs(); applyBone(selLimb,side,selPart); clearHighlight();
        autoSaveActiveSlot();
    });

    // ポージングタブの表示/非表示に連動してドラッグギズモを表示/非表示にする。
    // （統合メニューのタブ切り替えJSから呼び出される）
    window.__setPosingActive = function(active) {
        if (active) showGizmo(); else hideGizmo();
    };

    // ── 右腕IK（arm-ik-ui.js）との連携用の入口 ──────────────────────
    // FK/IKモード切り替え。on=true でFKギズモ等を止め、false で元に戻す。
    window._poseEditSetIKMode = function (on) {
        ikSuspended = !!on;
        if (ikSuspended) {
            if (dragging) { dragging=false; dragBone=null; dragPlane=null; controls.enabled=true; clearHighlight(); }
            hideGizmo();
        } else {
            syncInputs(); // IKで変わった角度を、FKの入力欄・スライダーへ反映する
            const tab = document.getElementById('tab-posing');
            if (tab && tab.classList.contains('active')) showGizmo();
            clearHighlight();
        }
    };

    // 関節1つぶんの角度（度）を、FKと同じ角度テーブルへ書き込んでボーンへ反映する。
    // IKの結果をFKと同じ経路で保存・出力させるための入口。NaN/Infinityは受け付けない。
    window._poseEditSetJointDeg = function (limb, side, part, xDeg, yDeg, zDeg) {
        if (!deg[limb] || !deg[limb][side] || !deg[limb][side][part]) return false;
        if (![xDeg, yDeg, zDeg].every(v => typeof v === 'number' && isFinite(v))) return false;
        const c = v => Math.max(-180, Math.min(180, v));
        deg[limb][side][part] = { x: c(xDeg), y: c(yDeg), z: c(zDeg) };
        applyBone(limb, side, part);
        return true;
    };

    // 初期化（初期表示タブは「キャラ」なのでギズモは隠しておく）
    updatePartButtons();
    hideGizmo();
})();
