// ============================================================
// 脚IKソルバー（二関節IK：太もも＋すね）  ※純粋な数学モジュール
// ------------------------------------------------------------
// ・THREE.js・DOM・既存のFK処理には依存しない（数値だけで計算する）。
// ・計算は「股関節ボーンの親（characterGroup）のローカル座標」で行う。
//   キャラの横回転（characterRotateWrapper）はこの座標系の外側なので影響しない。
// ・出力は既存のポーズデータと同じ角度表現（股関節：rx/ry/rz、膝：rx）。
//
// 既存モデルの脚の構造（character-body.js createLeg）：
//   股関節ボーン(root)から脚はローカル -Y 方向へ伸びる。膝ボーン(joint)は股関節の子で (0,-L1,0)、
//   足首(ankle)は膝の子で (0,-L2,0)。回転は Euler 'YXZ'。
//   膝は「ローカルX軸まわりの蝶番」で、rx>0 のとき すねが太ももに対して後ろ(-Z側)へ曲がる
//   （人の膝の向き。既存ポーズの膝の値も正）。膝は逆方向（rx<0）へは曲げない。曲げられるのは 0〜90°（下の DEFAULT_MAX_FLEX 参照）。
//
// 腕のIKとの違い：
//   ・膝は後ろ曲げの片方向だけ（0〜maxFlex、既定90°）。
//   ・膝の曲がる面は「股関節のひねり（ry）」で決まる。保存形式に ry を（任意項目として）
//     加えたので、膝の向きを自由に調整できる。
// ============================================================
(function (root) {
    'use strict';

    // 膝の最大屈曲＝90°。既存の保存形式は膝を rx だけで保存し、rx は ±90° の範囲でしか
    // 正確に復元できない（それを超えると保存→呼び出しで姿勢が変わる）ため、IKはこの範囲に制限する。
    // これより深く曲げる位置は「届かない位置」として、届く範囲へ制限される。
    const DEFAULT_MAX_FLEX = 90 * Math.PI / 180;

    function clamp(v, lo, hi) { return v < lo ? lo : (v > hi ? hi : v); }
    function isNum(v) { return typeof v === 'number' && isFinite(v); }

    function createResult() {
        return {
            rx: 0, ry: 0, rz: 0,        // 股関節（ラジアン、Euler YXZ）
            kneeRx: 0,                  // 膝（ラジアン、0以上＝後ろへ曲がる）
            knee: [0, 0, 0],            // 実際の膝の位置（ローカル）
            ankle: [0, 0, 0],           // 実際に届く足首の位置（ローカル）
            poleDir: [0, 0, 1],         // 採用した膝の向き（股関節→足首の線に垂直な単位ベクトル）
            clamped: false,             // 目標が届かず範囲内へ制限されたか
            reach: 0,                   // 0=最も曲げた状態 〜 1=完全に伸びた状態
        };
    }

    // 股関節→足首の線 w に垂直な膝の向き h を作る（作れなければ代替方向を試す）。
    // 候補：与えられたヒント → 前(0,0,1) → 上(0,1,0) → 横(1,0,0)
    const _h = [0, 0, 0];
    function makePerp(wx, wy, wz, px, py, pz) {
        const c = [px, py, pz, 0, 0, 1, 0, 1, 0, 1, 0, 0];
        for (let i = 0; i < c.length; i += 3) {
            const cx = c[i], cy = c[i + 1], cz = c[i + 2];
            if (!isNum(cx) || !isNum(cy) || !isNum(cz)) continue;
            const dp = cx * wx + cy * wy + cz * wz;
            const qx = cx - dp * wx, qy = cy - dp * wy, qz = cz - dp * wz;
            const ql = Math.sqrt(qx * qx + qy * qy + qz * qz);
            if (ql > 1e-4) { _h[0] = qx / ql; _h[1] = qy / ql; _h[2] = qz / ql; return true; }
        }
        return false;
    }

    //   (sx,sy,sz): 股関節の位置   (tx,ty,tz): 足首の目標位置   (px,py,pz): 膝の向きのヒント
    //   L1,L2: 太もも・すねの長さ   maxFlex: 膝の最大屈曲   out: createResult() の戻り値
    // 戻り値: true=解けた / false=入力が不正で何も書き込まなかった
    function solve(sx, sy, sz, tx, ty, tz, px, py, pz, L1, L2, maxFlex, out) {
        if (!out) return false;
        if (!isNum(sx) || !isNum(sy) || !isNum(sz) || !isNum(tx) || !isNum(ty) || !isNum(tz)) return false;
        if (!isNum(L1) || !isNum(L2) || L1 <= 1e-6 || L2 <= 1e-6) return false;
        if (!isNum(maxFlex)) maxFlex = DEFAULT_MAX_FLEX;
        maxFlex = clamp(maxFlex, 10 * Math.PI / 180, 175 * Math.PI / 180);

        const dx = tx - sx, dy = ty - sy, dz = tz - sz;
        const dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
        const dMax = L1 + L2;
        const dMin = Math.sqrt(Math.max(0, L1 * L1 + L2 * L2 - 2 * L1 * L2 * Math.cos(Math.PI - maxFlex)));

        let wx, wy, wz;
        if (dist > 1e-6) { wx = dx / dist; wy = dy / dist; wz = dz / dist; }
        else { wx = 0; wy = -1; wz = 0; }                 // 目標が股関節と同じ位置なら真下

        const d = clamp(dist, dMin, dMax);
        const clamped = Math.abs(d - dist) > 1e-6;

        if (!makePerp(wx, wy, wz, px, py, pz)) return false;
        const hx = _h[0], hy = _h[1], hz = _h[2];

        // 余弦定理：股関節での「股関節→足首」と「股関節→膝」の角度 A
        const cosA = clamp((L1 * L1 + d * d - L2 * L2) / (2 * L1 * d), -1, 1);
        const sinA = Math.sqrt(Math.max(0, 1 - cosA * cosA));

        // 太ももの向き u（膝は足首の線からヒント方向へ張り出す）
        const ux = wx * cosA + hx * sinA, uy = wy * cosA + hy * sinA, uz = wz * cosA + hz * sinA;
        const kx = sx + L1 * ux, ky = sy + L1 * uy, kz = sz + L1 * uz;           // 膝
        const ax = sx + d * wx, ay = sy + d * wy, az = sz + d * wz;              // 足首（到達位置）

        // すねの向き f と膝の曲げ角 k（0以上）
        const fx = (ax - kx) / L2, fy = (ay - ky) / L2, fz = (az - kz) / L2;
        const k = Math.acos(clamp(ux * fx + uy * fy + uz * fz, -1, 1));

        // 太ももローカル座標系：Y = -u（脚は-Y方向）、Z = 膝の張り出し側（膝が後ろへ曲がる＝すねは-Z側へ折れる）、X = Y×Z
        const Yx = -ux, Yy = -uy, Yz = -uz;
        const Zx = hx * cosA - wx * sinA, Zy = hy * cosA - wy * sinA, Zz = hz * cosA - wz * sinA;
        const Xx = Yy * Zz - Yz * Zy, Xy = Yz * Zx - Yx * Zz, Xz = Yx * Zy - Yy * Zx;

        // 回転行列（列=X,Y,Z）から Euler 'YXZ' を取り出す（three.js の setFromRotationMatrix と同じ式）
        const m23 = Zy;
        const rx = Math.asin(-clamp(m23, -1, 1));
        let ry, rz;
        if (Math.abs(m23) < 0.9999999) { ry = Math.atan2(Zx, Zz); rz = Math.atan2(Xy, Yy); }
        else { ry = Math.atan2(-Xz, Xx); rz = 0; }
        if (!isNum(rx) || !isNum(ry) || !isNum(rz) || !isNum(k)) return false;

        out.rx = rx; out.ry = ry; out.rz = rz;
        out.kneeRx = k;
        out.knee[0] = kx; out.knee[1] = ky; out.knee[2] = kz;
        out.ankle[0] = ax; out.ankle[1] = ay; out.ankle[2] = az;
        out.poleDir[0] = hx; out.poleDir[1] = hy; out.poleDir[2] = hz;
        out.clamped = clamped;
        out.reach = dMax > dMin ? clamp((d - dMin) / (dMax - dMin), 0, 1) : 1;
        return true;
    }

    const api = { solve: solve, createResult: createResult, DEFAULT_MAX_FLEX: DEFAULT_MAX_FLEX };
    if (typeof module !== 'undefined' && module.exports) module.exports = api;   // Nodeでのテスト用
    root.LegIKSolver = api;
})(typeof window !== 'undefined' ? window : globalThis);
